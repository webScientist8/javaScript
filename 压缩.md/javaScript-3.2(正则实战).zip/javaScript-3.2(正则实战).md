##javaScript-3.2(正则实战)

---
[TOC]

---

####-------复习正则-------
>正则的创建有两种方式：
>[字面量]
>`var reg=/^$/img;`
>[实例创建]//以项目为先的时候就不一样了，
>`var reg=new RegExp（'^$','img'）;`

```
//->创建一个正则，正则的规则是str变量存储的值，在这个值的左右两边各有一个@
var str ='zhufeng'；

var reg=/@zhufeng@/；//->如果str存储的值变为'piexun'了，我们正则中的zhufeng，也应该是'peixun'

//--------------
var reg=/@'+str+'@/;//->如果str存储的值变为'piexun'了，我们正则中的zhufeng，也应该是‘peixun’,结果却是'出现一到多次,r出现1到多次,正则里面全是元字符,失去了它本身的意义,不是代码,失去了它作为代码的意义,不能执行,+号也不是算法
eval('/@'+str+'@/')可以

//--------------
var reg=new RegExp('@'+str+'@');
//->实例创建方式，第一个参数是一个存放元字符的字符串，我们则可以使用字符串把一个变量的值动态设为正则的规则

//---------不行
var reg = /@'+str+'@/;//->让第一个'出现1到多次，让r也出现一到多次...整个本身就不是字符串，何谈字符串拼接  =>字面量创建方式中，斜杠包起来的所有字符都是元字符
```
![Alt text](./1502281205427.png)


>在使用实例创建的时候，我们在字符串中出现的元字符，有一些比较特殊，`\d`不适0~9之间的数字，我们应该写成`\\d`
![Alt text](./1502282218643.png)
![Alt text](./1502282258951.png)




####-------正则实战-------
`str.replace:替换`
>此方法一般都是和正则搭配使用的，否则有很多的替换需求根本是无法实现的
[str].replace([reg],[function])
```javascript
1.var str = 'zhufeng2017zhufeng2018';
2.
3.//------解决不了
4.//->需求：把所有的'zhufeng' 都替换为 'zhufengpeixun'
5.// str = str.replace('zhufeng', 'zhufengpeixun');
6.// str = str.replace('zhufeng', 'zhufengpeixun');
7.// console.log(str);
8.// =>'zhufengpeixunpeixun2017zhufeng2018'
9.
10.//------使用正则
11.str = str.replace(/zhufeng/g, 'zhufengpeixun');
12.console.log(str);
13.//=>'zhufengpeixun2017zhufengpeixun2018'
```
`[str].replace([reg],[function])`
```javascript
1.//-> 首先让[reg]和[str]进行匹配，每当匹配到一次，都会把[function]执行一次
2.
3.//-> 每当执行[function]的时候，浏览器都会把当前匹配捕获的结果(使用的是exec捕获)作为实参传递给这个函数
4.
5.//-> 在方法中出现的return后面是啥，都相当于把当前大正则匹配的结果替换成啥
6.
7.//----举个栗子
8.var str = 'zhu2017feng2018pei2019xun2020';
9.var reg = /\d+/g;
10.str = str.replace(reg, function () {
11.    //console.log('ok');//->'ok'*4
12.    //=>正则匹配了四次,我们传递的函数也执行了四次
13.
14.    //console.log(arguments);
15.    //->第一次 ['2017'...]
16.    //->第二次 ['2018'...]
17.    //->第三次 ['2019'...]
18.    //->第四次 ['2020'...]
19.    // arguments[0] ->当前本次大正则捕获的内容
20.    //=>每当执行这个方法的时候，浏览器都会把使用exec捕获到的结果作为实参传递给这个函数
21.
22.    return '@';
23.});
24.console.log(str);//->'zhu@feng@pei@xun@' 函数中返回的是啥,当前大正则匹配的那个字符串,就被替换成啥了
```
1,
```javascript
1.//->想把字符串中的阿拉伯数字替换为中文汉字
2.var str = '每月工资：16524';
3.var ary = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'];
4.str = str.replace(/\d/g, function () {
5.    return ary[arguments[0]];
6.});
7.console.log(str);
```
2,
```javascript
1.//->当前字符串中哪一个字母出现的次数最多，出现了多少次
2.var str = 'hello，my name is tom，i am 25 years old，i com from mars！';
3.
4.//1、获取每一个字母出现的次数
5.var obj = {};
6.str.replace(/[a-zA-Z]/g, function () {
7.    var val = arguments[0];//->每一次捕获到的字母
8.    if (obj.hasOwnProperty(val)) {
9.        //->当前这个字母已经存储过了
10.        //->我们让其出现的次数累加一即可
11.        obj[val]++;
12.        return;
13.    }
14.    //->当前字母还没有存储过,我们赋值为一,代表只出现一次
15.    obj[val] = 1;
16.});
17.//console.log(obj);//->{h: 1, e: 3, m: 7…}
18.
19.//2、获取最多出现的次数
20.var max = 1;//->假设出现次数最多一次
21.for (var key in obj) {
22.    if (obj.hasOwnProperty(key)) {
23.        obj[key] > max ? max = obj[key] : null;//->如果当前字母出现的次数比假设的还要大,修改假设的值
24.    }
25.}
26.
27.//3、根据最多出现的次数获取对应的字母
28.var ary = [];
29.for (key in obj) {
30.    if (obj.hasOwnProperty(key)) {
31.        obj[key] === max ? ary.push(key) : null;
32.    }
33.}
34.
35.console.log('最多出现：' + max + '次，对应的字母分别为：' + ary.join('|'));
36.
37.//-------------------
38.[方案二]
39.var str = 'hello，my name is tom，i am 25 years old，i com from mars！';
40.
41.//->把所有的非字母都替换掉
42.str = str.replace(/[^a-zA-Z]/g, '');
43.
44.//->把剩下的纯字母进行排序
45.str = str.split('').sort(function (a, b) {
46.    return a.localeCompare(b);
47.}).join('');
48.//->str:'aaaacdeeefhii...'
49.
50.//->把相邻一样的字母分别的捕获到,然后按照长度排序
51.var ary = str.match(/(.)\1*/g);
52.ary.sort(function (a, b) {
53.    return b.length - a.length;
54.});
55.
56.//->获取最后想要的结果
57.var max = ary[0].length,
58.    res = [];
59.for (var i = 0; i < ary.length; i++) {
60.    var cur = ary[i];
61.    if (cur.length !== max) break;
62.    res[res.length] = cur.substr(0, 1);
63.}
64.console.log(max + '<=>' + res);
```
3,
```javascript
1.var str = 'my name is {0}，i am {1} years old，i can {2}。';
2.var ary = ['zxt', 28, 'js'];
3.str = str.replace(/\{(\d+)\}/g, function () {
4.    //->arguments[0]:本次大正则捕获的内容
5.    //->arguments[1]:本次第一个小分组捕获的内容
6.    return ary[arguments[1]]
7.});
```
4,
```javascript
1.//->所有单词的首字母大写
2.var str = 'hello，my name is tom，i am 25 years old，i com from mars！';
3.str = str.replace(/\b([a-z])[a-z]*\b/ig, function () {
4.    var arg = arguments;
5.    return arg[1].toUpperCase() + arg[0].substr(1);
6.});
```
**思考题**
```
1.1、时间字符串格式化
2.var str = '2017-8-9 16:43:5';
3.//->把这个字符串可以变为 'xxxx年xx月xx日 xx时xx分xx秒' / 'xx-xx xx:xx 08-09 16:43' ... 变为一切你想需要的格式
4.
5.2、URL参数格式化
6.var url = 'http://www.zhufengpeixun.com/index.html?name=zxt&age=28&sex=1&type=0';
7.//->问号以后的都是`URL问号传参值`，接下里我们要把问号后面的信息拆解成为对象的键值对
8.//->{name:'zxt',age:28,sex:1,type:0}
```
```
->首先让[reg]和[str]进行匹配，每当匹配到一次，都会把[function]执行一次
->每当执行[function]的时候，浏览器都会把当前匹配捕获的结果（使用的是exec捕获）作为实参传递给这个函数
->在方法中出现的return后面是啥，都相当于把当前大正则匹配的结果替换成啥
```

1、需求
```javascript
var str='16524';
//->想把字符串变成'壹陆'

```

####-------盒子模型-------
JS中常用的盒子模型属性：获取元素的样式

**1、clientWidth / clientHeight：可视区域的宽度和高度**
>**clientWidth：width + padding(left&right)**
>**clientHeight：height + padding(top&bottom)**
和内容是否溢出以及是否设置了OVERFLOW没有关系,所谓的可视区域指的是一屏幕的区域,不含溢出的部分
console.log(oBox.clientWidth, oBox.clientHeight);

**获取当前浏览器可视窗口的宽度和高度(可视窗口:一屏幕的宽度或者高度)**
```javascript
document.documentElement.clientWidth||document.body.clientWidth
document.documentElement.clientHeight||document.body.clientHeight
```
//->操作当前浏览器的盒子模型属性,我们需要写两套
//=> document.documentElement.xxx 兼容大部分浏览器
//=> document.body.xxx 对于不兼容上述操作的浏览器使用这种办法获取



**2、clientTop / clientLeft ：上边框或者左边框的宽度(BORDER-WIDTH值)**
 没有clientRight和clientBottom这两个属性

 JS盒子模型属性获取的结果都是不带单位的
 获取的结果都是整数(会自动的把获取的结果四舍五入)



**3、offsetWidth / offsetHeight：在clientWidth&clientHeight的基础上加上边框即可**
 
 和内容是否溢出等没有任何的关系



 **4、scrollWidth / scrollHeight**

 没有内容溢出的情况下
  scrollWidth = clientWidth
  scrollHeight = clientHeight

 有内容溢出的情况下
  scrollHeight = paddingTop + 真实内容的高度(包含溢出的内容)
  scrollWidth = paddingLeft + 真实内容的宽度(包含溢出的内容)

  是否设置OVERFLOW:HIDDEN对获取的结果是产生影响的,而且每个浏览器获取的结果也还都不太一样，所以我们的这两个属性值，在有内容溢出的情况下，我们获取的值都是约等于的值

获取HTML页面的真实宽高(包含溢出的内容) '约等于的值'
```
 document.documentElement.scrollWidth||document.body.scrollWidth
 document.documentElement.scrollHeight||document.body.scrollHeight
```

//----------------------------------
/*以上的JS属性都是在特定的情况下使用(他们获取的是复合值)，如果想获取元素具体某一个样式属性的值，上述的属性就不合适了*/

**offsetLeft  /  offsetTop  /  offsetParent**
获取当前元素的左偏移/上便宜

**offsetParent:**获取当前元素的父级参照物
->在默认的情况下,BODY中出现的所有元素的父级参照物都是BODY(因为在同一个平面上),BODY本身的父级参照物是NULL
->我们通过设置POSITION定位,可以让元素脱离文档流,从而改变元素的父级参照物(CSS中我们当前元素是相对于谁定位的,那么JS中它的父级参照物就是谁)

**offsetLeft和offsetTop:**当前元素距离其父级参照物的左偏移和上偏移
->在大部分浏览器中,这个距离是从当前元素的外边框开始到父级参照物的内边框结束(不含父级元素的边框)
->IE8(纯IE8//非模拟器仿真),这个距离包含了父级参照物的边框,偏移量=当前元素的外边框到父级元素参照物的外边框

**1,scrollTop和scrollLeft:**  当前容器(一般都是当前页面)卷去的高度和宽度
->学习的13个JS盒子模型属性,只有这两个属性是'可读写'的(可以获取也可以设置),而其余的11个属性都是'只读'的
->为了兼容浏览器,我们设置或者获取页面的盒子模型属性值的时候,都要写两套
->有最小值,最小值是零,设置的值小于零也没用
->有最小值,真实页面的高度(document.documentElement.scrollHeight||document.body.scrollHeight)
可视窗口的高度(document.documentElement.client)

>>navigator.userAgent

JS中命名不识别[ - ],所以要捕获font-weight
就是/^fontWeight$/i;
命名也都是数字字母下划线,没有 - 
typeof null也是对象
空对象


*=?
默认margin?
''/
replace(/-/g,'')?


var obj=new Object({name:'珠峰'})
######关于盒子的偏移量
1,`offsetParent`
>获取当前元素的父级参照物
>
>1)默认情况下,所有元素的父级参照物都是body,body的父级参照物是null
>
>2)如果我们设置了position:relative/absolute/fixed,当前元素的父级参照物是 距离其最近的并且设置position样式的祖先元素

2,`offsetLeft`和`offsetTop`
>获取当前元素离


经常用用就会了,那几个获取DOM属性值
######关于滚动条
`scrollLeft`和`scrollTop`
>滚动条卷去的宽度和高度
>
>在13个JS盒子属性中,只有这两个属性是`可读写`的,
>其余的属性都是'只读'的
>
>两个属性可以设定的值存在边界范围
>最小值:0->到达最顶端了
>最大值:


######综合实战:图片懒加载(图片延迟加载)
>刚开始打开页面(渲染页面)的时候,我们不加载真实的图片,先用一张很小的默认图片(最好是10kb以内,1kb最好)占位,等页面(有时候也是第一屏)渲染完成,用户已经看到内容了,我们在依次加载真实的图片(更好的方式:只是先把第一屏幕的真实图片加载,当用户拉动到具体区域的时候,在把当前区域的真实图片加载)
>`加快页面第一屏幕的渲染速度`