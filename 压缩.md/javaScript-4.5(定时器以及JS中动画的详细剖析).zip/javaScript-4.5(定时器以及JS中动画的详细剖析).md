##javaScript-4.5(定时器以及JS中动画的详细剖析)

---
[TOC]

---
####定时器以及JS中动画的详细剖析
**定时器以及JS中动画的详细剖析**
>JS中的定时器有两种 
>`setInterval`
>`setTimeout`

######setInterval
>设置一个定时器，等待[interval]这么长时间后，会把[function]执行，以后每间隔[interval]这么长的时间，都会重新的再次把[function]执行，直到手动的去清除定时器为止
>`(clearInterval/clearTimeout)`

`window.setInterval([function],[interval])`


######setTimeout
>设置一个定时器，等待[interval]这么长的时间后，执行[function]，执行完成当前定时器停止工作(不是定时器清除,而是不工作了而已)，相对与setInterval来说，setTimeout执行一次就结束了

`window.setTimeout([function],[interval])`
```javascript
1.var n = 0;
2.window.setInterval(function () {
3.    console.log(++n);//->输出多次,从1开始一直累加下去
4.}, 1000);
5.
6.var m = 0;
7.window.setTimeout(function () {
8.    console.log(++m);//->输出一次1
9.}, 1000);
```
######定时器中的THIS和实参
>真实项目中，我们往往不仅想到达时间后执行一个函数，而且有时候需要改变这个函数中的THIS以及给函数传递一些实参，那么我们该如何处理呢？
```javascript
1.//->定时器在语法上还支持第三个参数，第三个参数写的值，是在函数执行的时候，给函数传递的实参值(在IE9及以下版本的浏览器中不兼容)
2.window.setTimeout(function (str) {
3.    console.log(str);//->'i am parameter'
4.}, 1000, 'i am parameter');
5.
6.//->一般情况下,当时间到达,执行这个匿名函数的时候,函数中的THIS指向WINDOW,而且当前函数中没有传递任何的实参
7.window.setTimeout(function () {
8.    console.log(this === window);//->TRUE
9.}, 1000);
10.
11.var obj = {name: 'zhufeng'};
12.window.setTimeout(function (num) {
13.    //->使用CALL或者APPLY
14.    //在设置定时器的时候就把当前的匿名函数执行了,把函数执行的结果赋值给了定时器 <=> setTimeout(undefined,1000) 1000MS后执行的是UNDEFINED,不是我们想要的效果
15.}.call(obj, 100), 1000);
16.
17.window.setTimeout(function (num) {
18.    //->使用BIND(IE6~8下不兼容)
19.    //使用BIND可以解决这个问题,BIND仅仅是预先把函数中的THIS和参数都准备好,设置定时器的时候,第一个参数还依然是个函数,当1000MS后执行函数,此时函数中的THIS已经是预先设置的OBJ了,NUM的值也是预先设定好的100这个值
20.}.bind(obj, 100), 1000);
21.
22.//=>利用了闭包可以保存内容的机制:在设置定时器的时候,我们预先形成一个不销毁的闭包(把需要的THIS和NUM提前通过CALL改变了),在这函数中返回一个小函数给定时器,1000MS后执行返回的小函数,在小函数中我们可以通过作用域链的机制找到需要的OBJ以及NUM
23.var obj = {name: 'zhufeng'};
24.window.setTimeout(function (num) {
25.    //->this:obj num=100
26.    var _this = this;
27.    return function () {
28.        //->1000MS后执行的是返回的小函数,把需要处理的事情放在小函数中即可
29.        console.log(num);//->100
30.        console.log(this);//->window
31.        console.log(_this);//->obj
32.    }
33.}.call(obj, 100), 1000);
```
######定时器的返回值
>设置一个定时器，都会有返回值，返回值是一个数字，代表当前是第几个定时器，随着设置定时器的增多，当前这个数字会一直累加（类似于去银行办理业务时候，我们领取的排队号）

>IE浏览器中也有返回值，也是一个数字，但是数字有点跳跃（谷歌下刷新页面，定时器计数的起始值是一，IE下是从上次的结束值开始的，但是把页面关掉重新打开，所有浏览器都是从一开始的）

`clearInterval([number]) / clearTimeout([number])`清除定时器的时候，我们只需要把一个数字传递进来，那么就清除了当前序号代表的这个定时器（不管你是用什么方法设置的，这两种方法都可以把定时器清除掉）
```javascript
1.var timer1=setInterval(function(){
2.    clearTimeout(timer1);//->也可以把定时器清除掉，只不过为了保证语义化，我们最好使用哪个方法设置的，就使用哪个方法把它清除即可，这里最好使用clearInterval
3.},1000);
```
当我们把页面中的某一个定时器清除掉之后，后面排队号是不会发生改变的，当再设置一个新的定时器，会继续基于最后一个序号累加（其实就是我们去银行办业务的那点逻辑）


######定时器中的递归思想
>需求：每间隔一秒钟我们都在原来的基础上累加一，当累加到五的时候，结束这样的操作
```javascript
1.//=>setInterval
2.var n = 0;
3.var timer = window.setInterval(function () {
4.    console.log(++n);
5.    if (n >= 5) {
6.        window.clearInterval(timer);
7.    }
8.}, 1000);
9.
10.//=>setTimeout
11.//->定时器执行一次后就不再执行了
12.var n = 0;
13.var timer = window.setTimeout(function () {
14.    console.log(++n);
15.    if (n >= 5) {
16.        window.clearInterval(timer);
17.    }
18.}, 1000);
19.
20.//->基于递归思想(函数执行的时候在调用自己执行)来实现我们的需求
21.var timer = null,
22.    n = 0;
23.function fn() {
24.    //->执行FN之前的第一步：把上一次没用的那个定时器清除掉
25.    window.clearTimeout(timer);
26.
27.    console.log(++n);
28.    if (n >= 5) {
29.        //->已经到达最后的阶段了,结束后讲不再执行FN,我们也就没有必要在设置新的定时器了
30.        return;
31.    }
32.    timer = setTimeout(fn, 1000);//->每一次执行FN结束后,为了过一秒后再次执行FN,我们在重新设置一个定时器
33.}
34.timer = setTimeout(fn, 1000);
```
####定时器的异步编程
>所有的定时器都是异步编程
![Alt text](./1503249479274.png)

```javascript
1.//=>定时器是异步编程
2.var n = 0;
3.window.setTimeout(function () {
4.    console.log(++n);//->2) 1
5.}, 1000);
6.console.log(n);//->1) 0
```
```javascript
1.//=>定时器的等待时间设置为零也不是立即执行:浏览器在处理一件事情的时候,会有一个最小的反应时间,我们写零浏览器是反应不过来的(谷歌一般最小的反应时间是5~6MS、IE是10~13MS,这个值会根据当前电脑CPU性能来决定的,每个人的不太一样)
2.var n = 0;
3.window.setTimeout(function () {
4.    console.log(++n);//->2) 1
5.}, 0);//->5~6
6.console.log(n);//->1) 0
7.
8.window.onscroll = function () {
9.    //->通过ONSCROLL也可以鉴证浏览器是有自己的处理最小反应时间的,我们快速滑动,在短时间内触发的此处就少一些,慢一些滑动,滑动相同的距离用的时间就会多一些,触发次数也会多一些
10.    console.log('OK');
11.};
```
```javascript
1.//=>定时器设定了等待时间,到达时间后也不一定执行,看当前主任务队列中是否有任务正在执行呢,如果有任务在执行,到时间后也依然需要继续等待(JS是单线程的)
2.var n = 0;
3.window.setTimeout(function () {
4.    console.log(++n);//->2) 1
5.}, 10);
6.
7.// var strTime = new Date();
8.for (var i = 0; i < 1000000000; i++) {
9.    //->循环10亿次
10.}
11.// var endTime = new Date();
12.// console.log(endTime - strTime);//->大约需要3057MS (通过这种方式可以监测代码执行的性能)
13.
14.console.log(n);//->1) 0
```
```javascript
1.//=>此时的主任队列中遇到了死循环,浏览器永远空闲不下来,定时器等不到执行的那一天了(真实项目中要杜绝死循环:出现死循环就什么都做不了)
2.var n = 0;
3.window.setTimeout(function () {
4.    console.log(++n);
5.}, 10);
6.while (1 == 1) {
7.    //->死循环
8.}
```
```javascript
1.//=>当主任队列任务完成完成后,会到等待任务队列中,把到时间的任务执行；如果很多等待的任务都到时间了,谁先到的,我们先执行谁；如果时间都很短,而且很相近,有些时候浏览器执行顺序混乱；
2.window.setTimeout(function () {
3.    console.log(1);//->3)
4.}, 100);
5.
6.window.setTimeout(function () {
7.    console.log(2);//->1)
8.}, 0);
9.
10.window.setTimeout(function () {
11.    console.log(3);//->2)
12.}, 50);
13.
14.for (var i = 0; i < 1000000000; i++) {
15.    //->循环10亿次:需要大概3~4S,上面所有的定时器都到时间了
16.}
```
>所有的事件绑定也都是异步编程
```
1.oImg.onload=function(){
2.    //->当图片加载成功后执行这个匿名函数
3.    alert('img is load success~');
4.}
5.oImg.onerror=function(){
6.    //->当图片加载失败后执行这个匿名函数
7.    alert('img is load error~');
8.}
9.alert('img is loading~');
```
>AJAX中也可以设置异步编程
```
1.var xhr=new XMLHttpRequest;
2.xhr.open('GET','地址',false); //->FALSE：同步   不写或者写TRUE：异步
3....
```
JS中的同步(SYNC)或者异步(ASYNC)编程是一个非常重要的知识点，也是高级前端开发工程师应该必备的技能：`promise` 这个设计模式就是处理异步编程的
####应用定时器实现JS动画
>真正的项目中，我们的动画基本上就两种

>1、不限定运动时间：规定的是步长（每隔多长时间走多远），我们控制需要运动的元素在现有位置的基础上累加步长即可

>2、限定运动时间：在规定时间内完成我们的动画，这个就需要我们获取总距离、总时间等信息，然后按照运动公式来处理了

######固定步长的匀速运动
>让红色的小盒子运动到右边界的位置:修改当前元素的LEFT样式值
```
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>珠峰培训</title>
    <link rel="stylesheet" href="css/reset.min.css">
    <style>
        .box {
            position: absolute;
            left: 0; /*不加LEFT,IE获取的LEFT是AUTO,谷歌下获取的是0*/
            width: 100px;
            height: 100px;
            background: red;
        }
    </style>
</head>
<body>
<div class="box" id="box"></div>

<script src="js/utils201708.js"></script>
<script src="js/2-2.js"></script>
</body>
</html>
```
![Alt text](./1503249746507.png)

```javascript
1.var minL = 0,
2.    maxL = utils.win('clientWidth') - box.offsetWidth;
3.
4.//->真实项目中为了避免全局变量的污染:我们定时器的返回值不要定义为全局的变量,而是设定在当前元素的自定义属性上(而且在任何的作用域中或者任何的位置,如果有需要我们都可以通过自定义属性的方式获取到这个结果)
5.box.timer = window.setInterval(function () {
6.    var curL = utils.css(box, 'left');
7.     //->为了防止多走一步会超过边界,少走一步到不了边界,我们JS实现动画的时候,边界判断都是加上步长来处理的(相当于模拟走一步看情况,如果模拟这一步超过了边界,我们直接让其运动到边界即可)
8.    if (curL + 10 >= maxL) {
9.        utils.css(box, 'left', maxL);
10.        window.clearInterval(box.timer);
11.        return;
12.    }
13.    curL += 10;
14.    utils.css(box, 'left', curL);
15.}, 17);
```
```javascript
1.//=>使用setTimeout实现这个需求
2.var minL = 0,
3.    maxL = utils.win('clientWidth') - box.offsetWidth;
4.function move() {
5.    //->每一次执行方法之前都把上一次没用的定时器清除掉(优化内存)
6.    window.clearTimeout(box.timer);
7.
8.    var curL = utils.css(box, 'left');
9.    if (curL + 10 >= maxL) {
10.        utils.css(box, 'left', maxL);
11.        return;
12.    }
13.    curL += 10;
14.    utils.css(box, 'left', curL);
15.
16.    //->方法执行完成后都会重新的设置一个定时器,让其17MS后重新执行这个方法(递归思想)
17.    box.timer = window.setTimeout(move, 17);
18.}
19.move();
```
>基于第一个需求：实现红色盒子在两个边界之间来回的反弹
```
1.var minL = 0,
2.    maxL = utils.win('clientWidth') - box.offsetWidth;
3.
4.move(maxL);
5.
6.function move(target) {
7.    //->首先区分是向左还是向右
8.    //1、如果当前的LEFT值<=目标值TARGET (向右)
9.    //2、如果当前的LEFT值>=目标值TARGET (向左)
10.    var curL = utils.css(box, 'left'),
11.        dir = curL <= target ? 'right' : 'left';
12.
13.    //->设置定时器实现运动即可
14.    var step = 10;
15.    box.timer = window.setInterval(function () {
16.        var curL = utils.css(box, 'left'),
17.            isEnd = false;
18.        dir === 'right' ? (curL + step >= target ? isEnd = true : null) : (curL - step <= target ? isEnd = true : null);
19.        if (isEnd) {
20.            utils.css(box, 'left', target);
21.            window.clearInterval(box.timer);
22.            //->控制下一次运动
23.            dir === 'right' ? move(minL) : move(maxL);
24.            return;
25.        }
26.        utils.css(box, 'left', dir === 'right' ? curL + step : curL - step);
27.    }, 17);
28.}
```
######限定时间的匀速动画
>需求还是沿袭上面的需求，只不过规定从左边界到达右边界总时间需要1000MS

>//=>总时间1000MS D 
>//=>起始位置 B 
>//=>总距离：目标位置-起始位置 C 
>//=>已经走的时间 T

>限定时间的匀速动画：就是随时获取到当前元素的位置即可，让元素运动到这个位置，一直到总时间结束，就完成了动画

>- T/D：已经走过的时间占总时间的百分比(我们已经走过百分之多少了)
>- T/D*C：已经走过的百分比乘以总距离=已经走过的具体距离(我们已经走了多远)
>- T/D*C+B：已经走过的距离+起始的位置=当前的位置(当前我们应该在哪)
```javascript
1.//->匀速动画公式：获取当前元素应有的位置
2.//->t:time 已经走过的时间
3.//->b:begin 当前元素起始位置
4.//->c:change 要运动的总距离
5.//->d:duration 动画的总时间
6.function Linear(t,b,c,d){
7.    return t / d * c + b;
8.}
```
```javascript
1.var time = 0,
2.    begin = utils.css(box, 'left'),
3.    target = utils.win('clientWidth') - box.offsetWidth,
4.    change = target - begin,
5.    duration = 5000;
6.box.timer = window.setInterval(function () {
7.    time += 17;
8.    //->当到达总时间的时候,结束动画
9.    if (time >= duration) {
10.        utils.css(box, 'left', target);
11.        window.clearInterval(box.timer);
12.        return;
13.    }
14.    //->获取当前元素的位置,并且让元素运动到这个位置
15.    var curL = Linear(time, begin, change, duration);
16.    utils.css(box, 'left', curL);
17.}, 17);
```
######多方向匀速动画
>基于上面的需求，实现从左上角到右下角或者实现当前元素多方向匀速运动
```javascript
1.//=>封装一个动画库:实现当前元素限定时间内的多方向匀速运动
2.~function () {
3.    //=>匀速运动的动画公式
4.    function Linear(t, b, c, d) {
5.        return t / d * c + b;
6.    }
7.
8.    //=>封装一个实现动画的方法
9.    //->curEle：当前要实现运动的元素
10.    //->target：要运动的目标位置 {xxx:xxx,xxx:xxx...}
11.    //->duration：运动的总时间,不传递默认是1000MS
12.    function animate(curEle, target, duration) {
13.        //1、获取T/B/C/D
14.        duration = duration || 1000;
15.        var time = 0,
16.            begin = {},
17.            change = {};
18.        for (var key in target) {
19.            if (target.hasOwnProperty(key)) {
20.                begin[key] = utils.css(curEle, key);
21.                change[key] = target[key] - begin[key];
22.            }
23.        }
24.
25.        //2、实现动画
26.        clearInterval(curEle.animateTimer);//->在设置新动画之前,把正在运行的其它动画都清除掉,防止多动画之间的冲突
27.        curEle.animateTimer = setInterval(function () {
28.            time += 17;
29.            //->结束动画
30.            if (time >= duration) {
31.                utils.css(curEle, target);
32.                clearInterval(curEle.animateTimer);
33.                return;
34.            }
35.
36.            //->通过匀速公式获取每个方向的当前位置,让元素运动到这个位置
37.            var current = {};
38.            for (var key in target) {
39.                if (target.hasOwnProperty(key)) {
40.                    current[key] = Linear(time, begin[key], change[key], duration);
41.                }
42.            }
43.            utils.css(curEle, current);
44.        }, 17);
45.    }
46.
47.    //=>暴露到全局使用
48.    window.zhufengAnimate = animate;
49.}();
50.
51.zhufengAnimate(box, {
52.    top: 300,
53.    left: 500,
54.    width: 10,
55.    height: 10,
56.    opacity: 0.2
57.}, 5000);
58.
59.zhufengAnimate(box, {
60.    width: 300,
61.    height: 300,
62.    opacity: 0.2
63.}, 500);
```
######案例：弹出框


![Alt text](./1503250009301.png)

>HTML && CSS
```
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>珠峰培训</title>
    <!--import css-->
    <link rel="stylesheet" href="css/reset.min.css">
    <link rel="stylesheet" href="css/dialog.css">
</head>
<body>
<!--dialog-->
<div class="dialogBg" id="dialogBg"></div>
<div class="dialog" id="dialog">
    <input type="button" value="close" id="dialogClose">
</div>

<!--import js-->
<script src="js/utils201708.min.js"></script>
<script src="js/animate.js"></script>
<script src="js/dialog.js"></script>
</body>
</html>
```
`dialog.css`
```css
html, body {
   width: 100%;
   height: 1000%;
   background: -webkit-linear-gradient(top left, lightsalmon, lightpink, lightcoral, lightblue);
}

dialogBg {
   display: none;
   position: fixed;
   top: 0;
   left: 0;
   z-index: 1000;
   width: 100%;
   height: 100%;
   background: #000;
   opacity: 0.5;
   filter: alpha(opacity=50);
}

.dialog {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    z-index: 2000;
    /*margin: -200px 0 0 -250px;
    width: 500px;
    height: 400px;*/
    margin: 0;
    width: 0;
    height: 0;
    opacity: 0;
    filter: alpha(opacity=0);

    background: #FFF;
    border-radius: 10px;
    overflow: hidden;
}

.dialog input[type='button'] {
    display: block;
    width: 100px;
    line-height: 35px;
}
```
`dialog.js`

```javascript
var dialogBg = document.getElementById('dialogBg'),
    dialog = document.getElementById('dialog'),
    dialogClose = document.getElementById('dialogClose');

document.body.onclick = function () {
    //->让弹出层显示
    utils.css(dialogBg, 'display', 'block');
    utils.css(dialog, 'display', 'block');

    //->让显示内容的提示框区域是从中间放大出来的
    zhufengAnimate(dialog, {
      width: 500,
        height: 400,
        marginLeft: -250,
        marginTop: -200,
        opacity: 1
    }, 200);
};

dialogClose.onclick = function (e) {
    utils.css(dialogBg, 'display', 'none');

    //->首先让弹出层先慢慢的消失
    zhufengAnimate(dialog, {
        width: 0,
        height: 0,
        marginLeft: 0,
        marginTop: 0,
        opacity: 0
   }, 200);
    //->问题：当我们动画结束后，应该让其display=none才可以

    e = e || window.event;
    e.stopPropagation ? e.stopPropagation() : e.cancelBubble = true;//->阻止事件的传播
};
```
######非匀速运动
>在匀速动画基础上支持非匀速的运动公式即可，继续完善我们的animate动画库
```javascript
1.~function () {
2.    //=>珠峰培训TWEEN算法动画公式(除了匀速还有非匀速的公式)
3.    //=>http://old.zhufengpeixun.cn/tween/
4.    var animationEffect = {
5.        Linear: function (t, b, c, d) {
6.            return c * t / d + b;
7.        },
8.        Bounce: {
9.            easeIn: function (t, b, c, d) {
10.                return c - animationEffect.Bounce.easeOut(d - t, 0, c, d) + b;
11.            },
12.            easeOut: function (t, b, c, d) {
13.                if ((t /= d) < (1 / 2.75)) {
14.                    return c * (7.5625 * t * t) + b;
15.                } else if (t < (2 / 2.75)) {
16.                    return c * (7.5625 * (t -= (1.5 / 2.75)) * t + .75) + b;
17.                } else if (t < (2.5 / 2.75)) {
18.                    return c * (7.5625 * (t -= (2.25 / 2.75)) * t + .9375) + b;
19.                } else {
20.                    return c * (7.5625 * (t -= (2.625 / 2.75)) * t + .984375) + b;
21.                }
22.            },
23.            easeInOut: function (t, b, c, d) {
24.                if (t < d / 2) {
25.                    return animationEffect.Bounce.easeIn(t * 2, 0, c, d) * .5 + b;
26.                }
27.                return animationEffect.Bounce.easeOut(t * 2 - d, 0, c, d) * .5 + c * .5 + b;
28.            }
29.        },
30.        Quad: {
31.            easeIn: function (t, b, c, d) {
32.                return c * (t /= d) * t + b;
33.            },
34.            easeOut: function (t, b, c, d) {
35.                return -c * (t /= d) * (t - 2) + b;
36.            },
37.            easeInOut: function (t, b, c, d) {
38.                if ((t /= d / 2) < 1) {
39.                    return c / 2 * t * t + b;
40.                }
41.                return -c / 2 * ((--t) * (t - 2) - 1) + b;
42.            }
43.        },
44.        Cubic: {
45.            easeIn: function (t, b, c, d) {
46.                return c * (t /= d) * t * t + b;
47.            },
48.            easeOut: function (t, b, c, d) {
49.                return c * ((t = t / d - 1) * t * t + 1) + b;
50.            },
51.            easeInOut: function (t, b, c, d) {
52.                if ((t /= d / 2) < 1) {
53.                    return c / 2 * t * t * t + b;
54.                }
55.                return c / 2 * ((t -= 2) * t * t + 2) + b;
56.            }
57.        },
58.        Quart: {
59.            easeIn: function (t, b, c, d) {
60.                return c * (t /= d) * t * t * t + b;
61.            },
62.            easeOut: function (t, b, c, d) {
63.                return -c * ((t = t / d - 1) * t * t * t - 1) + b;
64.            },
65.            easeInOut: function (t, b, c, d) {
66.                if ((t /= d / 2) < 1) {
67.                    return c / 2 * t * t * t * t + b;
68.                }
69.                return -c / 2 * ((t -= 2) * t * t * t - 2) + b;
70.            }
71.        },
72.        Quint: {
73.            easeIn: function (t, b, c, d) {
74.                return c * (t /= d) * t * t * t * t + b;
75.            },
76.            easeOut: function (t, b, c, d) {
77.                return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
78.            },
79.            easeInOut: function (t, b, c, d) {
80.                if ((t /= d / 2) < 1) {
81.                    return c / 2 * t * t * t * t * t + b;
82.                }
83.                return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
84.            }
85.        },
86.        Sine: {
87.            easeIn: function (t, b, c, d) {
88.                return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
89.            },
90.            easeOut: function (t, b, c, d) {
91.                return c * Math.sin(t / d * (Math.PI / 2)) + b;
92.            },
93.            easeInOut: function (t, b, c, d) {
94.                return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
95.            }
96.        },
97.        Expo: {
98.            easeIn: function (t, b, c, d) {
99.                return (t == 0) ? b : c * Math.pow(2, 10 * (t / d - 1)) + b;
100.            },
101.            easeOut: function (t, b, c, d) {
102.                return (t == d) ? b + c : c * (-Math.pow(2, -10 * t / d) + 1) + b;
103.            },
104.            easeInOut: function (t, b, c, d) {
105.                if (t == 0) return b;
106.                if (t == d) return b + c;
107.                if ((t /= d / 2) < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
108.                return c / 2 * (-Math.pow(2, -10 * --t) + 2) + b;
109.            }
110.        },
111.        Circ: {
112.            easeIn: function (t, b, c, d) {
113.                return -c * (Math.sqrt(1 - (t /= d) * t) - 1) + b;
114.            },
115.            easeOut: function (t, b, c, d) {
116.                return c * Math.sqrt(1 - (t = t / d - 1) * t) + b;
117.            },
118.            easeInOut: function (t, b, c, d) {
119.                if ((t /= d / 2) < 1) {
120.                    return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
121.                }
122.                return c / 2 * (Math.sqrt(1 - (t -= 2) * t) + 1) + b;
123.            }
124.        },
125.        Back: {
126.            easeIn: function (t, b, c, d, s) {
127.                if (s == undefined) s = 1.70158;
128.                return c * (t /= d) * t * ((s + 1) * t - s) + b;
129.            },
130.            easeOut: function (t, b, c, d, s) {
131.                if (s == undefined) s = 1.70158;
132.                return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
133.            },
134.            easeInOut: function (t, b, c, d, s) {
135.                if (s == undefined) s = 1.70158;
136.                if ((t /= d / 2) < 1) {
137.                    return c / 2 * (t * t * (((s *= (1.525)) + 1) * t - s)) + b;
138.                }
139.                return c / 2 * ((t -= 2) * t * (((s *= (1.525)) + 1) * t + s) + 2) + b;
140.            }
141.        },
142.        Elastic: {
143.            easeIn: function (t, b, c, d, a, p) {
144.                if (t == 0) return b;
145.                if ((t /= d) == 1) return b + c;
146.                if (!p) p = d * .3;
147.                var s;
148.                !a || a < Math.abs(c) ? (a = c, s = p / 4) : s = p / (2 * Math.PI) * Math.asin(c / a);
149.                return -(a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
150.            },
151.            easeOut: function (t, b, c, d, a, p) {
152.                if (t == 0) return b;
153.                if ((t /= d) == 1) return b + c;
154.                if (!p) p = d * .3;
155.                var s;
156.                !a || a < Math.abs(c) ? (a = c, s = p / 4) : s = p / (2 * Math.PI) * Math.asin(c / a);
157.                return (a * Math.pow(2, -10 * t) * Math.sin((t * d - s) * (2 * Math.PI) / p) + c + b);
158.            },
159.            easeInOut: function (t, b, c, d, a, p) {
160.                if (t == 0) return b;
161.                if ((t /= d / 2) == 2) return b + c;
162.                if (!p) p = d * (.3 * 1.5);
163.                var s;
164.                !a || a < Math.abs(c) ? (a = c, s = p / 4) : s = p / (2 * Math.PI) * Math.asin(c / a);
165.                if (t < 1) return -.5 * (a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
166.                return a * Math.pow(2, -10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p) * .5 + c + b;
167.            }
168.        }
169.    };
170.
171.    //=>realization animate (depend on utils)
172.    function animate(options) {
173.        //->initialize(init) parameters
174.        var _default = {
175.            curEle: null,
176.            target: null,
177.            duration: 1000,
178.            effect: animationEffect.Linear
179.        };
180.        for (var attr in options) {
181.            if (options.hasOwnProperty(attr)) {
182.                _default[attr] = options[attr];
183.            }
184.        }
185.        var curEle = _default.curEle,
186.            target = _default.target,
187.            duration = _default.duration,
188.            effect = _default.effect;
189.
190.        //->prepare T/B/C/D
191.        var time = 0,
192.            begin = {},
193.            change = {};
194.        for (var key in target) {
195.            if (target.hasOwnProperty(key)) {
196.                begin[key] = utils.css(curEle, key);
197.                change[key] = target[key] - begin[key];
198.            }
199.        }
200.
201.        //->running (clear other animate before running)
202.        clearInterval(curEle.animateTimer);
203.        curEle.animateTimer = setInterval(function () {
204.            time += 17;
205.            if (time >= duration) {
206.                utils.css(curEle, target);
207.                clearInterval(curEle.animateTimer);
208.                return;
209.            }
210.            var current = {};
211.            for (var key in target) {
212.                if (target.hasOwnProperty(key)) {
213.                    current[key] = effect(time, begin[key], change[key], duration);
214.                }
215.            }
216.            utils.css(curEle, current);
217.        }, 17);
218.    }
219.
220.    //=>setting window property
221.    window.zhufengEffect = animationEffect;
222.    window.zhufengAnimate = animate;
223.}();
```
####回调函数CALLBACK
**同步和异步编程**
>回调函数:把一个函数当做'实参',传递给另外一个执行的函数(A),在A执行的过程中,根据需求把B执行
```javascript
function fn(callBack){
//->callBack:我们传递进来的这个匿名函数
//callBack();
//->为了防止callBack不传递函数值,执行会报错,我们在回调函数执行的时候一般都会加判断,只有传递的是函数再执行
//typeof callBack==='undefined'?callBack():null;
callBack && callBack();
}
fn(function(){
//把匿名函数当做一个实参传递给FN
console.log('OK');
//->this:window  回调函数中的this一般都是window(严格模式:undefined)
})
```
>回调函数的小应用：完善动画库，让动画库支持动画完成后执行相关的事宜
```javascript
1.function animate(options) {
2.    var _default = {
3.        ...
4.        callBack: null
5.    };
6.    ...
7.    var callBack = _default.callBack;
8.    ...
9.    curEle.animateTimer = setInterval(function () {
10.        if (time >= duration) {
11.           ...
12.           //->run end：perform callback functions
13.           callBack && callBack.call(curEle);
14.            return;
15.        }
16.        ...
17.    },17);
```
```javascript
1.//=>当动画完成的时候：让当前元素的背景颜色变为PINK，让其透明度变为0.5，....
2.zhufengAnimate({
3.    curEle: box,
4.    target: {
5.        top: 300,
6.        left: 1000,
7.        width: 150,
8.        height: 150
9.    },
10.    effect: zhufengEffect.Bounce.easeOut,
11.    duration: 500,
12.    callBack: function () {
13.        //->把我们需要在动画完成处理的事情都放在这个函数中,在动画库中,动画完成后只需要把传递的这个回调函数执行即可
14.        //->this:box
15.        utils.css(this, {
16.            background: 'green',
17.            opacity: 0.5
18.        });
19.    }
20.});
```
>回调函数B可以在宿主函数A(B在A中执行的,所以可以把A叫做B的宿主函数)的`任何位置`执行(根据需求而定)，而且还可以`执行零到N次`，还可以给回调函数B`传递参数`或者`改变里面的THIS`，也可以`接收回调函数B的返回值`，进行后续的相关处理

>回调函数可以在宿主环境中‘肆无忌惮’的像正常的普通函数一样执行
`sort / forEach / map / filter ...`
```javascript
1.//->数组中的很多方法都是支持回调函数的，例如：sort中传递的匿名函数就是回调函数
2.ary.sort(function(a,b){
3.    //->SORT执行中,把传递的回调函数执行,不仅执行还给回调传递了两个实参的值
4.    return a-b;//->同样也接收了回调函数的返回结果,如果回调返回的是>0的值,SORT方法中会让当前项和后一项交换位置(SORT的原理)
5.});
6.
7.ary.forEach(function(item,index,input){
8.    //->数组中有多少项，就会把当前的回调函数执行多少次，不仅执行，还会给它传递参数：
9.    //item：当前遍历的这一项
10.    //index：当前遍历项的索引
11.    //input：遍历的原始数组
12.
13.    //->但是这个方法不支持回调函数的返回值(写了RETURN也没用)
14.
15.},[context]);//->第二个传递给FOREACH的参数是改变回调函数中的THIS指向
16.
17.
18.ary.map(function(item,index,input){
19.    //->MAP和FOREACH基本一样
20.    //->区别是MAP传递的回调函数支持返回值,我们RETURN是啥,相当于把当前的遍历项替换成啥
21.    return item*10; //->让原有的每一项乘以10
22.},[context]);
```
`replace`
```
1.//->当前正则和字符串匹配几次，我们的回调函数执行几次，并且把本次捕获的结果，传递给回调函数，回调函数中的返回值会把当前正则匹配的这一项替换掉
2.str.replace([reg],[function]);
```
`setInterval([function]...) / setTimeout([function]...)`
**重写forEach方法，实现兼容**
```javascript
1.Array.prototype.myForEach = function myForEach() {
2.    //->this:需要处理的数组
3.    var callBack = arguments[0],
4.        context = arguments[1];
5.    //->兼容
6.    if ('forEach' in Array.prototype) {
7.        this.forEach(callBack, context);
8.        return;
9.    }
10.
11.    //->不兼容(IE6~8)
12.    for (var i = 0; i < this.length; i++) {
13.        callBack && callBack.call(context, this[i], i, this);
14.    }
15.};
16.
17.var obj = {name: 'zhufeng'};
18.[12, 23, 34, 45].myForEach(function (item, index, input) {
19.    console.log(item, index, input);
20.}, obj);
```
>思考题：重写数组的map方法，也可以尝试重写字符串的replace方法