##javaScript-3.3(盒子模型)

---
[TOC]

---

>KWC(开胃菜) 
封装一枚检测数据类型的方法库
```
1.~function () {
2.    var obj = {
3.        isNumber: 'Number',
4.        isString: 'String',
5.        isBoolean: 'Boolean',
6.        isNull: 'Null',
7.        isUndefined: 'Undefined',
8.        isPlanObject: 'Object',
9.        isArray: 'Array',
10.        isRegExp: 'RegExp',
11.        isDate: 'Date',
12.        isFunction: 'Function'
13.    };
14.    var checkType = {};
15.    for (var key in obj) {
16.        if (!obj.hasOwnProperty(key)) continue;
17.
18.        checkType[key] = (function () {
19.            var className = obj[key];
20.            return function (val) {
21.                var reg = new RegExp('\\[object ' + className + '\\]');
22.                return reg.test(Object.prototype.toString.call(val));
23.            }
24.        })();
25.    }
26.    window.checkType = checkType;
27.}();
```


####-------盒子模型-------
JS中常用的盒子模型属性：获取元素的样式
####1、client系列
![Alt text](./offset.png)

**clientWidth / clientHeight：可视区域的宽度和高度**
>**clientWidth：内容本身width + padding(left&right)**
>**clientHeight：内容本身height + padding(top&bottom)**
>```javascript
console.log(oBox.clientWidth, oBox.clientHeight);
>```

**clientLeft  /  clientTop：上边框或者左边框的宽度(border-width值:盒子模型边框的宽度,)**
 >>**没有clientRight和clientBottom这两个属性**
 >
>**clientLeft=左边框的宽度(border-left-width)**
>**clientTop=上边框的高度(border-top-width)**

>JS盒子模型属性获取的结果都是不带单位的
>>**获取的结果都是整数(会自动的把获取的结果四舍五入)**

>>**这四个属性和内容是否溢出以及是否设置了OVERFLOW没有关系,所谓的可视区域指的是一屏幕的区域,不含溢出的部分**

获取当前浏览器可视窗口的宽度和高度(可视窗口:一屏幕的宽度或者高度)
```javascript
document.documentElement.clientWidth||document.body.clientWidth
document.documentElement.clientHeight||document.body.clientHeight


//->操作当前浏览器的盒子模型属性,我们需要写两套
//=> document.documentElement.xxx 兼容大部分浏览器
//=> document.body.xxx 对于不兼容上述操作的浏览器使用这种办法获取
```


---
####2、offset系列
**offsetWidth / offsetHeight：在clientWidth&clientHeight的基础上加上边框即可** 和内容是否溢出等没有任何的关系
 

 **offsetLeft  /  offsetTop  /  offsetParent**
获取当前元素的左偏移/上便宜/父级参照物

**offsetParent:**获取当前元素的父级参照物
>在默认的情况下,**body中出现的所有元素的父级参照物都是body**(因为在同一个平面上),body本身的父级参照物是null
>**我们通过设置position定位,可以让元素脱离文档流,从而改变元素的父级参照物**(css中我们当前元素是相对于谁定位的,那么js中它的父级参照物就是谁)

**offsetLeft和offsetTop:**当前元素距离其父级参照物的左偏移和上偏移
>**在大部分浏览器中,这个距离是从当前元素的外边框开始到父级参照物的内边框结束(不含父级元素的边框)**
>
>
>
>
>**IE8(纯IE8//非模拟器仿真),这个距离包含了父级参照物的边框,偏移量=当前元素的外边框到父级元素参照物的外边框**


---
####3、scroll系列
 **scrollWidth / scrollHeight**(获取页面真实宽高,包含溢出部分)**

 **没有内容溢出的情况下:**
  scrollWidth = clientWidth
  scrollHeight = clientHeight

 **有内容溢出的情况下:**
  scrollWidth = paddingLeft + 真实内容的宽度(包含溢出的内容)
  scrollHeight = paddingTop + 真实内容的高度(包含溢出的内容)

  是否设置OVERFLOW:HIDDEN对获取的结果是产生影响的,而且每个浏览器获取的结果也还都不太一样，所以我们的这两个属性值，在有内容溢出的情况下，我们获取的值都是约等于的值**(准确性很低,实际应用很差)**

获取HTML页面的真实宽高(包含溢出的内容) '约等于的值'


**1,scrollTop和scrollLeft:**当前容器(一般都是当前页面)卷去的高度和宽度
->**`学习的13个JS盒子模型属性,只有这两个属性是'可读写'的(可以获取也可以设置),而其余的11个属性都是'只读'的`**
->为了兼容浏览器,我们设置或者获取页面的盒子模型属性值的时候,都要写两套
->有最小值,最小值是零,设置的值小于零也没用
->有最小值,真实页面的高度(document.documentElement.scrollHeight||document.body.scrollHeight)
可视窗口的高度(document.documentElement.client)
```
 document.documentElement.scrollWidth||document.body.scrollWidth
 document.documentElement.scrollHeight||document.body.scrollHeight


//----------------------------------
/*以上的JS属性都是在特定的情况下使用(他们获取的是复合值)，如果想获取元素具体某一个样式属性的值，上述的属性就不合适了*/
```
(document.documentElement.scrollHeight||document.body.scrollHeight)
可视窗口的高度(document.documentElement.client)

>>navigator.userAgent


overflow:atuo  有溢出才有滚动条  overflow:scroll  没溢出也有滚动条


盒子模型  图片加载










