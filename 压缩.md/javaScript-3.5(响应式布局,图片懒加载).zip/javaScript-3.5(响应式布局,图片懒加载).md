##javaScript-3.5(响应式布局,图片懒加载)

---

[TOC]

---

####响应式布局案例:腾讯新闻APP资讯列表
#####1,why responsive web desigin?
>一个页面(H5页面),在不同尺寸的屏幕设备上,都能够良好的展示

**`[big screen]`**
![Alt text](./1502695897257.png)

**`[small screen]`**
![Alt text](./1502695950969.png)


#####2,如何编写响应式布局页面
`媒体查询法 OR 百分比布局 OR 流式布局`
`REM等比缩放布局`
`flexbox弹性盒模型布局`


这周我们就先初窥最简单的一个布局
![Alt text](./1502696093264.png)

第一步：设置viewport
```javascript
1.<!DOCTYPE html>
2.<html>
3.<head>
4.    <meta charset="UTF-8">
5.    <!--meta:vp [TAB]-->
6.    <meta name="viewport"
7.          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
8.    <!--
9.    设置当前页面的视口规则
10.        width=device-width：让当前HTML页面的宽度和设备(手机或者PAD等)的宽度保持一致,不设置的情况下,不管设备多宽,HTML页面默认的宽度是980(1024)
11.        user-scalable=no：禁止用户手动缩放
12.        initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0：初始、最大、最小的缩放比例都是1:1，页面既不会放大也不会缩小
13.    -->
14.    <title>珠峰培训</title>
15.</head>
16....
```
第二步：搭建页面

![Alt text](./1502696150968.png)


