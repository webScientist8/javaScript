##javaScript-2.3(localeCompare try JSON AJAX)

---
[TOC]

---

###1，把类数组转换为数组
>借用数组原型上面的**slice方法**，让slice方法执行的时候，里面的this指向arguments，这样就相当于slice在操作arguments这个类数组（原因：arguments是类数组,它的结构和数组太相似了,数组的一些循环遍历function,也同样可以用于类数组，**只是类数组的原型链上没有这些方法而已，不能直接调用，**为了省去自己再写这个方法的麻烦（**因为再写的这个类数组Slice方法跟数组[]的slice方法几乎一模一样，干嘛再写一遍**）所以通过call的this指向改变，来让slice方法指向arguments，从而达到调用，
>>**首先让数组：（[]）调用slice方法：（[].slice）,然后通过call改变slice的指向，并执行：（[].slice.call(arguments)）,就相当于（arguments.slice()）,**
```javascript
function fn(){
        //arguments:类数组
        
        console.log(arguments instanceof Array, arguments);  //false (3) ["12", "23", "34", callee: function, Symbol(Symbol.iterator): function]
        var ary=[].slice.call(arguments);  等同于  var ary=Array.prototype.slice.call(arguments);
        console.log(ary instanceof Array, ary);  //true (3) ["12", "23", "34"]
        return ary;
    }
    fn("12", "23", "34");
```
>**在JS中，元素集合（` HTMLCollection `的实例）以及节点集合(` NodeList `的实例)也是都是类数组**
>
>这些类数组也可以借用数组原型的方法，实现一些相关的操作，例如：借用slice把类数组转换成数组
>```javascript
1.var allTagList = document.getElementsByTagName('*');//->*通配符：获取当前页面中所有的元素标签
2.var ary = Array.prototype.slice.call(allTagList);
3.console.log(ary instanceof Array, ary);//->TRUE,数组
>```

---

>>***是通配符标签：获取当前页面中所有的元素标签**

>在IE低版本浏览器（IE6-8）中运行，我们发现ARG这个类数组是可以借用数组的方法正常操作的，但是元素集合和节点集合的类数组，无法借用数组原型上的方法，
>
>提示：Array.prototype.slice：‘this’不是JavaScript对象的错误
>
>所以在IE低版本中，我们把节点或者元素集合转换为数组的时候，就不能偷懒了，需要自己写循环处理
**原因：**在IE(6-8)下是把它们当成静态类数组来操作的，只能看不能改
>```javascript
var 
oList=document.getElementsByTagName('li');
//->IE6~8
var ary=[];
for(var i=0;i<oList.length;i++){
ary[ary.length]=oList[i]};
>```

>综上所述，如果我们想实现一个方法`把类数组转换为数组 `，我们需要考虑的事情
>1、兼容` [].slice.call（[类数组]）`这种模式的，我们使用这种模式，不能兼容的浏览器，我们使用` 循环 `一步步的处理
>2，如何验证是否兼容：不兼容的情况下，浏览器会抛出异常（报错），换句话说，只要报错了就是不兼容
```javascript
function toArray(likeAry) {
    var ary = [];
    try {
        //->如果不报错代表兼容
        ary = Array.prototype.slice.call(likeAry);
    } catch (e) {
        //->报错进入CATCH,代表不兼容(IE6~8)
        for (var i = 0, len = likeAry.length; i < len; i++) {
            ary[ary.length] = likeAry[i];
        }
    }
    return ary;
}
```
---
###2，sort和localeCompare拓展
####1，sort(function(a,b){a-b})的拓展
```
var ary = [12, 23, 14, 25, 23];
ary.sort(function (a, b) {
    //console.log(a, b);
    //->a:当前项
    //->b:后一项
    return 1;//->RETURN后面不一定非要写A-B,它的原理是:如果返回的是一个大于零的数,当前项后一项交换位置,如果是小于等于零的值,不做任何的处理
});
```
---
####2，localeCompare的拓展
**localeCompare**：可以做字符串的比较，按照拼音字母在字母表中的顺序排列，越靠后的字母越大
**如果数组里每一项是字符串（或者每一项是对象，而里面的属性值是字符串形式的），想要给数组里每项排序：**
>同样是使用sort，可是sort排序必须要比较数组里每两项的大小，localeCompare可以来比较每两项字符串的大小，把localeCompare应用于sort排序，就可以给以上情况的数组排序了；

**特**：哪怕比的是数组里每一项身上的一小部分，也是把整个这一项换位置，
如果数组里存的是对象，如果在sort的return里比的是数组里每两个对象的某一个属性值（属性名必须相同）的大小，相当于比较两个对象的大小，等同于通过比较每个对象的某个属性值的大小，来给每个对象排序，等同于通过比较每个对象的某个属性值，来判断每个整个对象的大小
```
var ary = ['任立欣', '单里斯', '叶祥磊', '史潇潇', '王梦雅', '罗傲', '刘丹', '王鹏', '黄冬莹', '李文鑫'];
ary.sort(function (a, b) {
    return a.localeCompare(b);
});

//->localeCompare：可以做字符串的比较，按照拼音字母在字母表中的顺序排列，越靠后的字母越大
// '任立欣'.localeCompare('单里斯') ->1
// '单里斯'.localeCompare('任立欣') ->-1
// 'renlixin'<=>'danlisi'
```
---
###2，浏览器异常信息捕获` try catch finally `
```
try{
//->JS代码
}catch（e）{
//->TRY中的JS代码执行，如果出现错误，会进入到CATCH中（没出错不进入这里）
//->e（error）是一个形参（名字可以随便起，但是必须写形参，不写语法报错）e.message;存储的是当前JS代码执行的报错信息
}finally{
//->不管JS执行是否报错，最后都会执行finally中的内容（项目中不常用）
}
```
>**使用try catch的作用**
>- 可以捕获到错误信息的同时，防止浏览器抛出异常信息，这样即使当前代码报错了，也不会影响下面的执行
> -可以监听到报错，我们可以利用这个机制，做一些兼容处理：把需要执行的代码放在try中，如果不兼容报错了，我们在catch中处理兼容即可
>```
try{
    console.log(a);}
catch(e){
    console.log(e.message);//->报错信息
}
    var b=13;
    console.log(b);//->13
>```

**平时项目中：**
```
//->很多公司，会把项目代码最外面包裹一层TRY CATCH，以此来收集错误信息，而且还不会在浏览器控制台抛出异常错误
      try{
          //->项目的所有JS代码
      }catch(e){
          //->收集报错信息：统计到服务器上
      }  
```
---
**try catch是防止浏览器抛出异常信息，如果我们想手动抛出异常信息**
>**手动在浏览器中抛出异常信息**
```
使用TRY CATCH捕获异常信息的时候，后面代码还可以继续执行，但是项目中难免会出现这样的需求：我们上面代码如果不能正常的执行，下面代码也不会让他执行了，此时需要我们手动抛出异常来阻止下面的代码执行

throw new Error('您的人品欠费，请充值~~')//->创建Error类的一个实例：一条错误信息
try {
    console.log(a);
} catch (e) {
    // e.message
    throw new ReferenceError('The system is busy, please wait a moment!');}
```
####**new 了Error类的一个实例，Error就是错误信息的类**
Error这个类划分了几个常用的小类：
->ReferenceError：引用错误
->TypeError：类型错误
->RangeError：范围错误
->SyntaxError：语法错误
。。。


---
###3，JSON
> 它不是一个新的数据类型，它只是某种特殊的数据格式：` 把属性名用双引号包起来` 格式，就是JSON格式的数据 `(JSON格式的对象/JSON格式的字符串) `，JSON格式没啥特殊的，操作起来和对象以及字符串一样
> ```javascript
> var obj={name:'珠峰',age:8};
> var jasonObj={'name':'珠峰','age':8}//->JSON对象
> 
> var str="{name:'珠峰'}"；
> var jsonStr='{"name":"珠峰"}'；//->JSON字符串  //单双引号不能连着用，必须单双错开用
> ```
> 在前后端数据交互中，服务器端返回给客户端的数据一般都是JSON格式的，也就是JSON的作用：承载服务器和客户端的数据交互
![Alt text](./1501737502065.png)



**方法一：` JSON.parse `全称:` window.JSON.parse `**
>在全局对象中存在一个JSON对象，这个对象中有一个**parse方法：把JSON格式的字符串转换为JSON格式的对象**
>```javascript
>var str='[{"id":1,"name":"珠峰"},{"id":2,"name":"周啸天"}]';
>
>var jsonDate=JSON.parse(str);
>console.log(jsonDate);//->JSON对象 ->[{"id":1,"name":"珠峰"},{"id":2,"name":"周啸天"}]
>```
>>**意义：服务器端返回给客户端的一般都是JSON字符串，我们操作里面属性和属性值的时候不好操作，此时我们需要先把这个字符串变为对象才可以**

**方法二：` JSON.stringify `**
> 把JSON格式的对象（普通格式的也可以）转换为json格式的字符串
> ```javascript
> var ary=[{
	> id:1,
> name:'珠峰'
> },{
> id:2
> name='周啸天'
> }]；
> var jsonStr=JSON.stringify(ary);
> //->JSON格式的字符串
> //->'[{"id":1,"name":"珠峰"},{"id":2,"name":"周啸天"}]'
> ```
>>**意义：有些时候，客户端不仅仅向服务器发送请求，还会给服务器传递点内容（例如：注册的时候，需要客户端把用户输入的内容传递给服务器），客户端传递给服务器的一般都是JSON格式的字符串，此时就需要我们使用stringify这个方法把得到的结果变为字符串，再传递给服务器**

---
>**在IE6和IE7中，window下没有JSON这个对象，**也就是不能使用`JSON.parse`和`JSON.stringify`这个两个方法了
>` JSON.parse `被` eval `取代了
>` JSON.stringify `没有能取代的方法,需要自己编写复杂的处理程序(思考题)
>```
var str='[{"id":1,"name":"珠峰"},{"id":2,"name":"周啸天"}]';
eval('('+str+')');//->手动给需要解析的字符串外层包裹一个小括号，防止解析出错：对于‘{。。。}’这种格式的字符串，如果外层不多加一层小括号，解析出来，属于语法不符合
>```

>综上我们现在有一个需求：编写一个方法，能够实现把JSON字符串转换为JSON对象
> - 兼容：` JSON.parse `
> - 不兼容：` eval `
> - 如果window中存在JSON这个属性，属于兼容，反之不兼容
> ```
> //->toJSON：converts a string into a object (JQ)
> function toJSON(str){
            return 'JSON'in window?JSON.parse(str):eval('('+str+')');
        }
> ```

###4，AJAX
async javascript and xml
我们可以通过AJAX向服务器发送请求，并且获取到服务器返回的内容
```javascript
1.//->创建一个AJAX对象
2.var xhr=new XMLHttpRequest;
3.
4.//->打开一个请求的URL地址
5.xhr.open([请求方式],[请求的URL地址],[同步或者异步]);
6.//=> xhr.open('GET','xxx/xxx.json',false); false代表的是同步编程:当从服务器端把数据获取到之后，才可以做别的事情
7.
8.//->监听AJAX的状态改变，接收服务器返回的结果
9.xhr.onreadystatechange=function(){
10.    if(xhr.readyState===4 && xhr.status===200){
11.        //->从服务器获取数据成功，下面的操作就可以接收到服务器端返回的结果
12.        xhr.responseText;
13.    }
14.}
15.
16.//->向服务器发送请求
17.xhr.send(null);
```
---
###5，SORT
```javascript
    var ary=[12,23,14,25,23];
    ary.sort(function(a,b){
        //console.log(a,b);
        //a:当前项
        //b:后一项
        
        return a-b;
      //renturn 1;//->return后面不一定非要写A-B，它的原理是：如果返回的是一个大于零的数，当前项后一项交换位置，如果是小于等于0的值，不做任何的处理
    });
```


---
>**eval小知识**
>eval（）只执行（）的第一项；因为eval只有一个形参
eval（2，3）只执行3
eval（“2，3，4，”，5）执行“2，3，4”

---
>**包装对象**
var num1=2；
num1= new Number