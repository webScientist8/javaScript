##javaScript-1.4(好像没讲什么东西,周末班复习)

---
[TOC]

---



####单例模式:
return{fn：fn}；//->  使用return把在外面需要的返回，外面设置一个变量接收即可，这样在外面就可以使用里面的东西了；为什么返回一个对象：对象中可以存储很多的信息，我们可以把很多东西都返回给外面用，如果只是return，只能返回一次，只能给外面用一个东西，太单一了


####变量提升：
在当前作用域中，JS代码从上到下执行之前，浏览器首先会把带VAR/FUNCTION关键字的进行提前声明或者定义
声明(declare):告诉当前作用域有这样一个变量
定义(defined):给变量赋值

VAR和FUNCTION的区别
VAR：只声明，不定义(默认值是undefined)
FUNCTION：声明+定义
```javascript
console.log(fn);//->输出函数本身
    console.log(fn(20));//->先把函数执行,把函数执行的返回结果输出(RETURN)
    function fn(i) {
        var m = 13;//->在全局作用域中，这个M是不会在全局下变量提升的,因为此时它还是函数开辟空间中的一个字符串而已(函数执行的时候形成一个私有作用域,在这个私有作用域中它才会提升)
        console.log('ok');
    }
```
![Alt text](./1.png)

####在全局作用域下
- 1)声明一个全局变量,也相当于给WINDOW增加了一个对应的属性,属性值就是变量存储的值
var num = 13;
console.log(num);//->13 输出变量存储的值
console.log(window.num);//->13 输出WINDOW的属性值

console.log(n, m);//->Uncaught ReferenceError: m is not defined 不带VAR的不能进行变量提升(不能再定义之前使用,否则会报错,而一旦当前行代码报错,后面代码都不执行了)
var n = 13;//->既有变量的意思,也有WINDOW属性的意思
m = 14;//->没有创建变量层次上的意思,仅仅是给WINDOW增加了一个叫做M的属性名,属性值14

->变量提升：不管条件是否成立,判断体中的内容也要参与变量提升(但是此时不管是VAR/FUNCTION都只是提前声明不在定义了)；在代码执行过程中，如果条件不成立直接跳过判断继续执行，如果条件成立，进入到判断体中的第一件事情就是给函数赋值定义

-> 'xxx' in window：IN是用来判断当前属性是否隶属于这个对象的,属于返回TRUE,反之FALSE
var obj = {name: '周啸天', age: 28};
console.log('name' in obj);//->TRUE
console.log('sex' in obj);//->FALSE
```
/*
 * 全局下的变量提升
 *   var a;        =>undefined
 *   function fn;  =>undefined
 *
 * 在全局下声明的变量都相当于给window加了一个属性
 *   window.a=undefined
 *   window.fn=undefined
 */
console.log(a, fn);
if (!('a' in window)) {//->'a' in window =>TRUE 条件不成立,判断体中的代码不执行
    var a = 13;
    function fn() {console.log('ok');}
}
console.log(a, fn);
```
```
/*
 * 变量提升
 *   f = xxxfff000
 *   g = xxxfff111
 */
function f() {return true;}
function g() {return false;}
~function () {
    /*
     * 自执行函数执行,形成一个私有的作用域
     *   形参赋值
     *   变量提升：function g;  不管条件是否成立都要提升,但是提升的时候只是声明不定义了
     */
    if(g()&&([]==![])){//->undefined()：Uncaught TypeError: g is not a function
        f=function () {return false;}//->等号右边是值,是不进行变量提升的
        function g() {return true;}
    }
}();
console.log(f());
console.log(g());


function f() {return true;}
function g() {return false;}
~function () {
    /*
     * 变量提升
     *   g = xxxfff222  G是当前私有作用域的私有函数
     */
    if(g()&&([]==![])){
        //->g():TRUE
        //->[]==![]: []==false 0==0 TRUE
        f=function () {return false;}//->F不是这个作用域中私有的 <=>window.f=function () {return false;}
    }
    function g() {return true;}
}();
console.log(f());//->FALSE
console.log(g());//->FALSE
```
![Alt text](./3-1.png)

#####匿名函数
```
//匿名函数之自执行函数：函数的创建和执行一起完成了
// ;(function () {//->前面加分号:防止上面的函数创建完成后面不加分号,以后代码压缩成一行的时候,让自执行函数成为上面函数的执行参数
//     console.log('ok');
// })();
// ~function () {}();
// !function () {}();
// +function () {}();
// -function () {}();
```
![Alt text](./3-2.png)

#####重名情况下的变量提升
```javascript
window.fn=函数地址
window.fn=13;
不管是函数名还是变量名，其实都是一样的，都可以叫做变量名，如果名字一样了，也算是重复的

在变量提升的阶段,如果当前的这个名字已经被声明过了,没必要在重复声明,只需要给它赋值定义即可
//------------------------------
/*
 * 变量提升
 *  fn = xxxfff111
 *     = xxxfff222
 */
fn();//->2
function fn() {console.log(1);}
fn();//->2
var fn=13;//->fn=13
fn();//->13():Uncaught TypeError: fn is not a function
function fn() {console.log(2);}
fn();
var fn=function(){console.log(3);}
fn();
```


####实现页面投票按钮
```
var submit = document.getElementById('submit'),
    countBox = document.getElementById('countBox');

submit.onclick = function () {
    /*
     * 变量提升: var n;
     */
    var n = 0;
    countBox.innerHTML = ++n;
    /*
     * 代码执行完成后：栈内存销毁
     */
};
```
//->利用了全局作用域不销毁的原理，把我们需要累加的值存储在全局变量中，每一次点击执行函数，在形成的私有作用域中，把全局变量的值进行累加，这样就可以实现我们的需求了
//=>弊端：如果都遵循这个思路,会导致全局变量过多(全局变量可能出现污染的问题),所以在某些正规的小团队中,是命令规定禁止使用全局变量的
```
var n = 0;
submit.onclick = function () {
    countBox.innerHTML = ++n;
};

->给ONCLICK赋值的时候:形成一个不销毁的私有作用域(私有变量N也不销毁了)
->ONCLICK=XXXFFF111
->弊端：不利于性能优化
submit.onclick = (function () {
    var n = 0;
    return function () {//->xxxfff111
        countBox.innerHTML = ++n;
    }
})();


~function () {
    var n = 0;
    submit.onclick = function () {
        countBox.innerHTML = ++n;
    }
}();
```

**思路三：自定义属性**
把值存储在自定义属性上也可以实现保存的作用
```javascript
submit.zhufengN = 0;
submit.onclick = function () {
    //->this:submit
    countBox.innerHTML = ++this.zhufengN;
};
```

**思路四：利用innerHTML的设置内容的机制**
```javascript
submit.onclick = function () {
    countBox.innerHTML++;
    //->countBox.innerHTML = parseInt(countBox.innerHTML) + 1;
};
```
//->思考题：回去后把反对的按钮也加上


---
![Alt text](./1.png)
![Alt text](./3-1.png)
![Alt text](./3-2.png)
