##javaScript-1.3（栈堆内存,闭包,THIS）

-------------------

[TOC]


-------------------

性能优化：堆栈内存的销毁问题（存内存空间不能被销毁，存值可以被销毁,只有栈内存可以存堆内存,堆内存,只能存值）只是大的堆内存自己被销毁，这个大的空间没有了，它就不再存有那些属性了，只是不再存有那些属性或者地址，那些属性本身不受影响，(堆内存跟堆内存之间没有联系,一个销毁完全不影响另一个,除非被销毁的那个是它的地址的唯一占用,这样,如果那个被销毁了,就没有人再知道它的地址了,也没有人再占用它了,这样,系统会认为它是无用的,会在空闲时间,把他清除,也就是销毁掉,)（如果只被大内存里的属性引用了地址，那会受影响）
它的属性名没有了，但是里面存的小东西，不受影响，如果是小的堆内存，如果还被别人占用，那不被销毁
#####1、堆内存释放（>如果有变量（函数名）占用了堆内存的地址，那么当前的堆内存则不能释放
>
>如果当前堆内存的地址，没有被任何的东西所引用，当前的堆内存就没用了，浏览器会在空闲的时候清理掉这些没用的堆内存（谷歌浏览器）
>
>IE下的堆内存释放采用的是计数器机制，被一个变量占用，计数器累加1，如果之前的某个占用被移除，计数器减1；但是很多时候IE的计数器计数的时候出现问题，导致“内存泄漏”

```
var obj={name：'珠峰培训'}；  //->obj=xxxfff000  此时的obj把堆内存占用了

obj=null；  //->obj不占用堆内存了，浏览器在空闲的时候会销毁这个无用的堆内存

	  null：空对象指针，不指向任何的堆内存  */
```

#####2、栈内存（作用域）的释放
>**全局作用域：**浏览器加载页面的时候形成全局作用域，在浏览器中把当前页面关闭的时候，全局作用域销毁（刷新一次页面：先销毁，再创建）
>
>**私有作用域：**函数执行的时候会形成私有作用域，一般情况下，函数执行完成，形成的这个私有作用域立即释放销毁
>
>**特殊情况：**当私有作用域中的某一个东西（一般指的都是私有作用域中开辟的那个堆内存）被作用域以外的变量给占用了，当前的私有作用域（栈内存）就不能销毁了，这个私有作用域不销毁，代表着它里面存储的私有变量也不会销毁了；
![Alt text](./0[Z2NQM$11XDCK03T80IB7.jpg)

**示例：**
```
 var num = 12;
    function fn() {
        var num = 13;
        return function () {
            console.log(num);
        }
    }
    var f = fn();
    f();
    function sum() {
        var num = 14;
        f();
    }
    sum();
```
![Alt text](./1501124370785.png)



---

####闭包的作用
>你了解过闭包么？（易车面试题）

目前外界普遍认为“形成一个不销毁的私有作用域”才是闭包
```
var fn=（function（）{
var n=12；
return function（）{
console.log(++n);
}
}）();
```
**闭包的作用：**
- 保护里面的私有变量不受外界干扰（里面的变量和全局变量没关系，防止全局变量污染）
>你了解过闭包么？ (易车面试题)

目前外界普遍认为“形成一个不销毁的私有作用域”才是闭包

```
//->例如：我们封装类库或者组件插件的时候，为了防止和全局变量冲突，我们都使用闭包把代码包裹起来（jQuery就是这样处理的）
；（function（）{
var fn=null；
var jQuer=function（）{
。。。
}//->jQuery=xxxfff000

window.jQuery=window.$=jQuery;//->给全局增加了一个jQuery的属性和￥的属性，这样在外面就可以使用jQuery或者$了，
}）（）；

var fn=undefind；//->和闭包中的fn没关系，防止了冲突和污染
$()//->$=xxxfff000
```

- 形成一个不销毁的作用域，来保存某些值
可以形成一个不销毁的作用域，来存储一些值

```
//->选项卡部分代码节选
for (var i = 0; i < oList.length; i++) {
 oList[i].onclick = (function (i) {
     return function () {
         tabChange(i);
     }
 })(i);
}

for (var i = 0; i < oList.length; i++) {
  ~function (i) {
       oList[i].onclick = function () {
           tabChange(i);
       }
   }(i);//->每一次循环把全局作用域下的i变量存储的值,当做实参传递给形参i(私有变量)
}
```


---
#####JS中的同步变成和异步编程
**同步：**
自上而下依次执行，上面的事情没有处理完，下面事情一直在等待
**异步：**
当上面的事情在等待执行的时候，我们不等，继续执行下面的事情
<font color='red'>JS中的事件绑定属于异步编程

>JS中的事件绑定：事件绑定  定时器  回调函数  


---
####THIS
this:函数执行的主体(容器)
>this这个，是执行这个方法的主体
```
//以下所有规律都是在非严格模式下生效

//->自执行函数执行，函数中的THIS是window
~function（）{
console.log(this);//->window
}();

//->给元素的事件绑定方法，当事件触发方法执行的时候，方法中的this是当前操作的元素
oDiv.onclick=function(){
console.log(this);//->oDiv
}

//->方法执行，看方法名前面是否有“点”，有“点”，“点”前面是谁，THIS就是谁，没有“点”，THIS就是window（没有“点”，THIS就是window，有“点”就是在window下的某个对象里执行的，有“点”意味着把当前函数变成属性值赋给某个对象了（引用数据类型的数据）同时有“点”意味着，当前函数的主体肯定是个引用数据类型的数据，同样是说：这个引用数据类型的数据的一个属性名的属性值占用了这个函数的引用空间地址）优先级高！！
function fn（）{
console.log(this);
}
var obj={
aa:fn
};
fn()://->THIS:window
obj.aa();//->THIS:obj


//->在构造函数中，类(函数体中)出现的THIS.xxx=xxx中的this是当前类一个的实例
```

---
####小知识：
#####i++和++i的区别
都是在自身基础上累加1，不同地方在于和其他值运算的时候，累加1在前还是在后
>i++：先运算，再累加－－(i++)也是一样，小括号无效，
>++i：先累加，再运算
```javascript
var i=10;
console.log(5+i++);  //先计算5+i,计算完成后再把i累加1  =>15
console.log(5+（i++）);  //也是先计算5+i,计算完成后再把i累加1  =>15
i=12
-------
var i=10;
console.log(5+(++i));->16 i->11
```
**思考题**
```
var i = 4;
var res = 5 + (++i) + (i++) + (i++) + (++i);
console.log(res, i);
```


![Alt text](./2.png)
![Alt text](./3.png)



思考题
```

以下代码的功能是要实现为5个input按钮循环绑定click点击事件，绑定完成后点击1、2、3、4、5五个按钮分别会alert输出0、1、2、3、4五个字符。
    请问如下代码是否能实现？
    如果不能实现那么现在的效果是什么样的？
    应该做怎样的修改才能达到我们想要的效果，并说明原理？
<div id="btnBox">
    <input type="button" value="button_1" />
    <input type="button" value="button_2" />
    <input type="button" value="button_3" />
    <input type="button" value="button_4" />
    <input type="button" value="button_5" />
</div>

<script type="text/javascript">
    var btnBox=document.getElementById('btnBox');
    var inputs=btnBox.getElementsByTagName('input');
    var l=inputs.length;
    for(var i=0;i<l;i++){
        inputs[i].onclick=function(){
            alert(i)
        }
    }
</script>
```
```
 var 
num = 10;//20 40
    var obj = {
        num: 5,//10
        fn: (function () {
            this.num *= 2;
            num *= 2;//20
            var num = 3;//9  27

            return function () {
                this.num *= 2;
                num *= 3;
                console.log(num);
            }
        })()
    };
    var fn = obj.fn;//fn=function ()
    fn();//9
    obj.fn();//27   40     10
    console.log(num, obj.num);
```
![Alt text](./4]R]FL55X@T{9W76QIN8.png)



综合题
```
var num = 10;
var obj = {
    num: 5,
    fn: (function () {
        this.num *= 2;
        num *= 2;
        var num = 3;

        return function () {
            this.num *= 2;
            num *= 3;
            console.log(num);
        }
    })()
};
var fn = obj.fn;
fn();
obj.fn();
console.log(num, obj.num);

```
