##javaScript-1.5(面向对象 构造函数 原型模式)

---
[TOC]

---



**复习**
```javascript
var num = 2;
var obj = {num: 3};
obj.fn = (function (num) {
    this.num *= 2;
    num *= 2;
    return function () {
        this.num *= 2;
        num *= 3;
        console.log(num);
    }
})(obj.num);//->把obj中num的属性值作为实参传递给自执行函数的形参num
var fn = obj.fn;
fn();
obj.fn();
console.log(num, obj.num);
```
![Alt text](./1501508637078.png)


####1，单例模式
>我们把描述一个东西特点特征的属性和方法汇总到一起，实现了分组分类，避免了相互之间的冲突；我们汇总在一起的那个对象称之为一个单独的个体或者是一个单独的实例=>"单例模式"
```
var person1={
name:"张三"，
age:25}；

var person2={
name:"李四"，
age:29}；

//->person1和person2都是一个单独的个体（单独的实例）相互的name和age属性并不冲突，这就是基于"单例模式"的设计思想构造出来的
//->person1或者person2不仅仅称之为对象名了，在单例模式下，他们称之为："命名空间"
```
>单例模式：把描述事务的属性和方法放在同一个命名空间下，实现分组分类的作用，避免了相互之间的冲突（全局变量的污染）
```
//高级单例模式：基于JS高级编程技巧“惰性函数思想”封装的单例模式
var nameSpace=(function(){
//->自执行函数执行形成一个不销毁的私有作用域(闭包)
return{
init:function(){},
...
}
})();
nameSpace.init();
```
>单例模式是项目开发中最常用的设计模式之一，我们团队协作按模块化开发的时候，基本上都是基于单例的思想设计的，避免相互代码的冲突
```
//模拟百度开发，百度首页按功能可以分为以下几个模块：
// ->频道页卡
// ->换肤
// ->天气
// ...


//->PUBLIC
//utils就是项目的公共方法库
var utils=(function(){
return{
cookie:function(){}
...
}
});

//->A
var channelRender=(function(){
return{
init:function(){...},
drag:function(){...},
...
}
})();

//->B
var changeSkinRender=(function(){
    return {
        init:function(){...},
        change:function(){
            utils.cookie();
            changeSkinRender.init();//->this.init();
        },
        ...
    }
})();
changeSkinRender.change();
```
####2、工厂模式
>体现出了函数的封装特点：把实现一个功能的代码进行封装，以后想实现这个功能，直接的执行函数即可，这样不仅仅实现了代码的“低耦合高内聚”，而且实现了批量生产的快速开发=>“工厂模式”

####3、面向对象编程思想（OOP）
var num =  new Number( 1 )

>OOP：Object Oriented Programming

> - 对象：JS中一切都是需要学习和研究的对象（泛指，抽象的名词）

> - 类：对象的具体细分（例如：自然界中分为植物类、动物类、每一个大类还可以分为小类。。。）

> - 实例：每一个类别中具体的个体事物

学习数组
> JS中有一个内置的类Array(数组类)，每一个数组都是这个类的一个实例，我们拿出一个数组(拿出一个实例)来进行研究，研究出来的知识，我们可以说所有的数组都具备这些知识
> 内置类:
> Number,String,Boolean,Null,Undefined
> Object、Array、RegExp、Date、Function....

> HTMLCollection(元素集合类)，通过getElenmentsBYTagName等获取的元素集合都是它的一个实例
> NodeList(节点集合类)，通过getElenmentsByName等获取的节点集合都是它的一个实例
> HTMLDivElement(每一个HTML标签都有一个自己对应的类)HTMLElement Element Node EventTarget...



JS本身就是基于面向对象的思想构造出来的语言，所以JS中肯定有很多的“内置类”
- 每一种数据类型都有一个自己所属的内置类
 + Number：每一个数字都是它的一个实例
 + String：每一个字符串都是它的一个实例
 + Boolean：
 + Null：
 + Undefined：
 + Objecr：
	 + Array：
	 + RegExp
	 + Date
	 + 。。。
 + Function
 + 。。。
![Alt text](./1501762685730.png)


> 每一个数据类型所用的方法，都是当前所属的类提前设定好的，实例就可以调取这方法了，例如：Array：数组类，数组为每一个实例都提前设定了一些方法
>以上这些方法就是数组给它的实例提供的，所以作为数组的实例，是可以调取这些方法使用的 

- 元素或者节点集合类
	- HTMLCollection：元素集合类，通过DOM的方法获取到的元素集合都是它的实例，例如：getElementsByTagName、getElementsByClassName。。。
	- NodeList：节点集合类，通过DOM方法获取到的节点集合都是它的一个实例，例如：getElementByName、childNodes。。。

- DOM元素标签对应的内置类：每一个元素标签都有一个自己对应的内置类
	- div：HTMLDivElement
	- a：HTMLAnchorElement
	- p：HTMLParagraphElement
	- 。。。
- HTMLElement
- Element
- Node
- EventTarget
- 。。。

####4，构造函数设计模式
>>**构造函数跟内置类也可以当做普通函数执行**
>基于面向对象的编程思想，创建“自定义类”，基于自定义的类，创建相关的实例...
```
Object.prototype.x=100;
function Fn(){

//new Fn
/1，向普通函数执行一样：形成的一个私有的作用域
/2，形参赋值&&变量提升
/3，浏览器会在当前作用域中开辟一个新的对象（当前类的一个实例），并且让当前作用域的上下文（THIS）变成这个实例对象
/4，代码自上而下执行

this.xxx=xxx;  =>给当前实例增加一些私有的属性
var  xxx=xxx；=>

}
```
```
instanceof：检测当前对象（实例）是否属于这个类的运算符
console.log(p1 instanceof Array);  //false
console.log(pi instanceof Person);  //true

var a=/^$/;
console.log(a instanceof Array);  //false
console.log(a instanceof Person);  //true

in：检测某一个属性是否隶属于某一个对象
console.log("say"in p1);  //true

hasOwnProperty:  检测某一个属性是否为当前对象的私有属性
console.log(p1.hasOwnProperty('say'));//true
/*
 *hasPublicProperty：detects whether the current property is the public attribute of the instance
 * @parameters
 *   key：[string] properties to be detected
 *   obj：[object] object to be detected
 * @return
 *   true or false
 * by team on 2017-07-30
 */
function hasPublicProperty(key,obj){
return (key in obj) && !obj.hasOwnProperty(key);
}//()只是增加优先级，加很多（）也不会报错，i++增加（），增加优先级也没用，

hasPublicProperty:在C模块框架和常用方法时候比较常用
很重要知识点
```

####5、基于构造函数模式的原型模式成为公有的{ dir(Objct.prototype) }

![Alt text](./1504443176545.png)

> 构造函数模式中拥有了类和实例的概念，并且实例和实例之间是相互独立开的 ->实例识别
> 基于构造函数模式的原型模式解决了 方法或者属性公有的问题->把实例之间相同的属性和方法提取成公有的属性和方法 ->想让谁公有就把它放在CreateJsperson.prototype
```
1，所有的函数数据类型(普通函数、类)天生具备一个属性：prototype，这个属性的值是一个对象,当前类的公共属性和方法都在这个对象中存储着呢

2、prototype上浏览器天生给它加上一个属性:constructor（构造函数），这个属性存储的值就是当前类(函数)本身

3、每一个对象数据类型(普通对象、实例、prototype组和正则等类的实例、函数也是对象)也会天生自带一个属性：__proto__,这个属性存储的值是它对应的类的prototype属性的值


```
function Fn( ){
    this.x =100;
}
Fn.prototype.getX = function ( ){
      console.log ( this.X);
};
var f1 = new fn;
var f2 = new fn;

```

2、Object是js中所有对象数据类型的基类(最顶层的类)
一、f1 instanceof Object -> true 因为f1通过__proto__可以向上级查找，不管有多少级，最后总能找到Object
二、在Object.prototype上没有__proto__这个属性

3、原型链模式
f1.hasOwnProperty("x"); ->hasOwnProperty是f1的一个属性
但是我们发现在f1的私有属性上并没有这个方法，那如何处理
一、通过 对象名.属性名 的方式获取属性的时候，首先在对象的私有的属性上进行查找，如果私有中存在这个属性，则获取的是私有的属性值;
如果私有的没有，则通过__proto__找到所属的原型a(类的原型上定义的属性和方法都是当前实例公有的属性和方法),原型上存在的话，获取的是公有的属性值;
如果原型上也没有，则继续通过原型上的__proto__继续向上查找，一直找到Object.prototype为止...
这种查找机制就是我们的"原型链模式"

f1.getX === f2.getX           true

//f1忽略了私有查找公有
f1 __proto__.getX === f2.getX true
f1.getX === fn.prototype.getX true

f1.sum === f2.__proto__       false
f1.sum === fn.prototype.sum   false

f1.hasOwProperty  f1.__proto__.__proto__.hasOwnProperty
在IE浏览器中，我们原型模型上也是同样的原理，但是IE浏览器怕在通过__proto__把公有的修改，禁止我们使用__proto__

f1.sum = function(){
     修改自己私有的sum
};

f1.__proto__.sum = function (){
    修改所属类原型上的sum
};
 
Fn.prototype.sum = function(){
    IE浏览器使用 修改公有的sum
};
```




实例在调取属性和方法的时候，首先看是否为自己的私有属性，如果不是私有的，则通过__proto__到类的原型上找公有，如果公有也没有，则继续通过__proto__向上一直找。。。一直找到Object.prototype上为止，我们把这种一层层向上查找的机制叫做“原型链”

**小知识**
```
var p1=new Person()
var p2=new Person;  //如果不需要传递实参，我们是可以省略小括号的

console.log(new Date);//创建Date类的一个实例:当前客户端的时间
```

>构造函数：我们不写return默认返回的是当前类的实例，如果我们手动编写了return，根据返回值的不一样，有不同的结果
1，return  基本数据类型；  对最后结果不产生任何影响，返回的还是当前类的实例
2，return  引用数据类型；  自己设置返回的内容会覆盖默认返回的内容，返回的结果将不再是当前类的实例了

####构造函数有3个特性：
new Person()
 *   1、把Person变为一个类：类都是函数数据类型的(包含内置类)
 *   2、把Person当做一个普通的方法来执行
 *   3、P1就是当前类的实例：实例都是对象数据类型的
 *   3、是一个对象，所有的函数都是对象数据类型的，


