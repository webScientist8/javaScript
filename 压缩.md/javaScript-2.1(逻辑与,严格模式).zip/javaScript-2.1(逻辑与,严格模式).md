##javaScript-2.1(逻辑与,严格模式)

---
[TOC]

---




####逻辑与（&&）和逻辑或（||）
1,作为条件的分隔符
```javascript
if(1==1&&2==2){
//->逻辑与：左边的条件为真，右边条件也为真，整体才为真，否则就是假=>'并且'
}
if（1==1||2==2）{
//->逻辑或：左右两边的条件只有一面为真，整体就为真，反之为假=>'或者'
}
```
2，赋值运算符
```javascript
//->逻辑或：A||B，首先验证A的真假，如果A为真，返回的结果是A，如果A为假，返回的结果是B（不管B是啥）
function fn(num1，num2){
//->参数初始化：如果参数没有传递，给参数一个默认值

//typeof num1==="undefined"?num1=0:null;(传统判断做法：麻烦)
num1=num1||0；
num1=num2||0；
//->一般我们这样处理参数初始化即可，比较的简便，但是这样不严谨：传递值了，但是传递的是false/0/空字符串啊，这样返回的也是右边的值
}
fn（10）；

------------------------------------------
//->逻辑与：A&&B，A如果为真，返回右边的B，如果A为假，返回左边的A（和逻辑或的操作是相反的）
fn&&fn（）；//->如果当前函数存在，则让函数执行，否则函数不执行（不严谨：如果fn是10呢？）

typeof fn==='function'？fn():null;
//->和上面的意思相同，但是这样方式严谨一些

------------------------------------------
//->一个运算中既有||也有&&，&&的优先级高于||
var res=0||2&&3&&0||false
/*
 *2&&3  ->3
 *3&&0  ->0
 *0||0  ->0
 *0||false  ->false
 */
console.log(res);//->false
```

####获取上一个哥哥元素节点（兼容所有浏览器）
previousElementSibling【不兼容】
```javascript
function prev(curEle){
if('previousElementSibling'in curEle){
return curEle.previousElementSibling}
}
```


####动态操作DOM
```javascript
var oDiv=document.createElement
```
####arguments
在非严格模式下（现在写的JS默认就是非严格模式），arguments中的每一项值，和函数的形参存在“映射关系”->arguments中的某一项值改变，形参也会改变->形参改变了，arguments中的这一项值也会变
**'use strict';**

####严格模式和非严格模式的区别：
3，非严格模式下,自执行函数中的THIS是window严格模式下,自执行函数中的THIS是undefined，非严格模式下，如果不确定执行的主体，this都是window，但是严 格模式下要求，不知道执行主体的时候，this都是undefined
>**区别1**
```javascript
'use strict';  //->开启JS的严格模式：需要写在当前作用域的起始行

 严格模式和非严格模式的区别：
  ->非严格模式下,创建一个变量,如果不带VAR,相当于给window加了一个属性,不会报错的

  ->严格模式下,不允许出现不带VAR的变量

a = 12;
console.log(a);  //->Uncaught ReferenceError: a is not defined
```
>**区别2**
```

 严格模式和非严格模式的区别：
  ->非严格模式下,自执行函数中的THIS是window
  ->严格模式下,自执行函数中的THIS是undefined

  =>非严格模式下，如果不确定执行的主体，this都是window，但是严格模式下要求，不知道执行主体的时候，this都是undefined

 
 ~function () {
     console.log(this);//->window
 }();

 ~function () {
     'use strict';
     console.log(this);//->undefined
 }();

function fn() {
    console.log(this);
}
fn();//->this:window
fn.call();//->this:window
fn.call(null);//->this:window
fn.call(undefined);//->this:window

function sum() {
    'use strict';
    console.log(this);
}
sum();//->this:undefined
sum.call();//->this:undefined
sum.call(null);//->this:null
sum.call(undefined);//->this:undefined
```
>**区别3**
```

 严格模式和非严格模式的区别：
  ->非严格模式下,arguments和形参存在映射关系(一个改,另外一个也跟着自动改)
  ->严格模式下,arguments和形参没有映射关系

function fn(x, y) {
    arguments[0] = 100;
    console.log(x);//->100

    y = 200;
    console.log(arguments[1]);//->200
}
fn(10, 20);

function sum(x, y) {
    'use strict';
    arguments[0] = 100;
    console.log(x);//->10

    y = 200;
    console.log(arguments[1]);//->20
}
sum(10, 20);
```
>**区别4**
```javascript

 严格模式和非严格模式的区别：
  ->严格模式下不允许使用：arguments.callee/arguments.callee.caller这两个属性

function fn() {
    console.log(arguments.callee);  //->存储的是当前函数本身:FN
    console.log(arguments.callee.caller);  //->存储的是当前函数在哪个作用域下执行的,如果是在全局下执行的,返回结果是NULL,如果AA函数中执行的,它存储的值就是AA本身                                
}
fn();

function aa() {
    fn();
}
aa();
             
function sum() {
    'use strict';
    //console.log(arguments.callee);//->Uncaught TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them
}
sum();
```


####作业题讲解
**1、有一个` div: <div class=”w” name=”h” id=”div1”></div> `我想获取这一个div你有几种解决办法(不考虑兼容)：**
```javascript
1.document.getElementById('div1')
2.document.getElementsByTagName('div')[0]
3.document.getElementsByClassName('w')[0]
4.document.getElementsByName('h')[0]
5.
6.//->querySelector/querySelectorAll在不需要考虑兼容的情况下(例如:移动端开发),我们经常使用这两个方法获取需要的DOM元素
7.document.querySelector("#div1/.w/div/[name='h']")
8.document.querySelectorAll("#div1/.w/div/[name='h']")[0]
```
**2、获取当前浏览器屏幕的宽度和高度(兼容所有的浏览器)**
```
1.//->获取宽度
2.document.documentElement.clientWidth||document.body.clientWidth
3.//->获取高度
4.document.documentElement.clientHeight||document.body.clientHeight
```
**3、获取上一个哥哥元素节点(兼容所有浏览器)**
**` previousElementSibling [不兼容] `**
```javascript
1.function prev(curEle){
2.    if('previousElementSibling' in curEle){
3.        return curEle.previousElementSibling;
4.    }
5.    //->不兼容的浏览器执行如下操作
6.    var pre = curEle.previousSibling;
7.    while(pre&&pre.nodeType!==1){
8.        pre=pre.previousSibling;
9.    }
10.    return pre;
11.}
```
**4、动态创建一个div标签，并且添加到body的最后面位置；把刚才创建的克隆一份一模一样的，添加到刚才创建的div前面；最后把新创建的这个DIV删除；**
```javascript
1.var oDiv=document.createElement('div');
2.document.body.appendChild(oDiv);
3.
4.var cloneDiv=oDiv.cloneNode(true);
5.document.body.insertBefore(cloneDiv,oDiv);
6.
7.document.removeChild(oDiv);
```
**5、实现找到第n项到第m项的内容，返回一个新的数组(原有数组不变) `ary.slice(n-1,m)`**

**6、一些判断** 
>[]==false true 
![]==false true 
[]==![] true 
Number(“13px”)==NaN false 
5+”3”-2 51 
If(“3px”*3){alert(“true”)}else{alert(“false”)} 'false' 
If(“3px”+3){alert(“true”)}else{alert(“false”)} 'true' 
If（document.body）{alert(“ok”);}else{alert(“no”)} 'ok' 
alert([]) 空字符串 
null==undefined true 
null===undefined false

####作用域练习题
```javascript
1. var ary=[1,2,3,4];
2. function fn(ary){
3.    ary[0]=0;    
4.    ary=[0];    
5.    ary[0]=100;    
6.    return ary; 
7. }
8. var res=fn(ary);//->把全局下的ARY存储的值xxxfff111当做实参传递给FN这个函数   
9. console.log(ary);    
10. console.log(res);  
```
![Alt text](./1501585865064.png)


**[2]**
```javascript
1.//->变量提升
2.//var foo;  bar = xxxfff000;
3.var foo=1; 
4.function bar(){
5.    //->形参赋值:无
6.    //->变量提升: var foo; (不管条件是否成立，都会进行提前声明，函数也只是提前声明，此时foo是私有变量)
7.    if(!foo){//-> !undefined 取反后的结果是TRUE,条件是成立的
8.        var foo=10; //->把私有变量foo的结果赋值为10
9.    }
10.    console.log(foo); //->10
11.}
12.bar();
```

**[3]**
```javascript
1.var a=4;
2.function b(x,y,a) {    
3.     alert(a); //->3
4.     arguments[2]=10; //->把形参a的值也同时修改为10了       
5.     alert(a); //->10
6.}
7.a=b(1,2,3);   
8.alert(a); //->undefined
```
![Alt text](./1501585976966.png)


**[5]**
```javascript
1.var a=9; 
2.function fn(){ 
3.    a=0;       
4.    return function(b){ 
5.        return b+a++; 
6.    }    
7.}
8.var f=fn()
9.var m=f(5);
10.alert(m);
11.var n=fn()(5);
12.alert(n); 
13.var x=f(5);
14.alert(x);
15.alert(a);
```
![Alt text](./1501586032212.png)


**[6]**
```javascript
1.var num = 10;
2.var obj = {num: 20};
3.obj.fn = (function (num) {
4.    this.num = num * 3;
5.    num++;
6.    return function (n) {
7.        this.num += n;
8.        num++;
9.        console.log(num);
10.    }
11.})(obj.num);
12.var fn = obj.fn;
13.fn(5);
14.obj.fn(10);
15.console.log(num, obj.num);
```
![Alt text](./1501586092798.png)


**面向对象：构造函数和原型链**
**[1]**
```javascript
1.function Fn() {
2.    var num=100;
3.    this.x = 100;
4.    this.y = 200;
5.    this.getX = function () {
6.        console.log(this.x);
7.    }
8.}
9.Fn.prototype.getX = function () {
10.    console.log(this.x);
11.};
12.Fn.prototype.getY = function () {
13.    console.log(this.y);
14.};
15.var f1 = new Fn();
16.var f2 = new Fn;//->new执行的时候,如果不需要给函数传递参数值,小括号加或者不加无所谓,都是一样的
17.
18.//[原型查找]---------------------
19.console.log(f1.getX === f2.getX);
20.console.log(f1.getY === f2.getY);
21.console.log(f1.__proto__.getY === Fn.prototype.getY);
22.console.log(f1.__proto__.getX === f2.getX);
23.console.log(f1.getX === Fn.prototype.getX);
24.console.log(f1.constructor);
25.console.log(Fn.prototype.__proto__.constructor);
26.
27.//[this]-------------------------
28.f1.getX();//->首先找的是私有的getX,并且getX方法中的this是f1,console.log(this.x)相当于输出f1.x =>100
29.f1.__proto__.getX();//->首先找的是公有的getX,并且getX方法中的this是f1.__proto__,console.log(this.x)相当于输出f1.__proto__.x =>undefined
30.f2.getY(); //->this:f2，console.log(this.y)相当于输出f2.y =>200
31.Fn.prototype.getY();//->this:Fn.prototype，console.log(this.y)相当于输出Fn.prototype.y =>undefined
32.
33.//=>总结：
34.//->首先看方法执行中的this是谁(函数执行,点前面是谁,this就是谁)
35.//->把JS代码中的this换位刚才分析的结果
36.//->按照原型链查找的机制，直接判断输出的值即可
37.
38.//[思考题]----------------------
39.console.log(f1.num);
40.f1.num=1000;
41.console.log(f2.num);
42.Fn.prototype.num=2000;
43.console.log(f2.num);
44.
45.console.log(f1.hasOwnProperty('x'));
46.console.log(Fn.prototype.hasOwnProperty('getY'));
47.console.log(f1.hasOwnProperty('getY'));
48.console.log(f1.hasOwnProperty('hasOwnProperty'));
49.console.log(Fn.prototype.hasOwnProperty('hasOwnProperty'));
50.console.log(Object.prototype.hasOwnProperty('hasOwnProperty'));
51.
52.//->in检测是否存在这个属性
53.//->hasOwnProperty检测是否为它的私有属性
54.Object.prototype.myHasPubProperty=function myHasPubProperty(){
55.    //->完成你的JS
56.}
57.f1.myHasPubProperty('getY'); //=>true
```
![Alt text](./1501590294634.png)
