##javaScript-2.2(函数的三种角色,CALL)

---

[TOC]

---

总结的一些规律：
>instanceof：检测实例是否属于这个类
>- 规律：只要是在当前实例原型链上出现的类，使用instanceof检测的时候，出现的结果都是true
>f instanceof Fn  ->true
>f instanceof Objecr  ->true
>
>每一个类的原型都应该拥有一个constructor属性，这个属性存储的值就是当前函数本身；但是如果我们把prorotype的值重新指向一个新的堆内存（自己手动创建的对象），类的原型就会失去constructor这个属性；所以在以后开发的时候，如果我们想批量给原型设置属性和方法，**属性猪腰（需要注意）constructor，防止覆盖**，
```javascript
~function(){
var jQuery=function(){
    //...
};
//->让jQuery这个类的原型重新指向了新的堆内存，这样jQuery的constructor属性就被覆盖了，这样不好，我们需要自己手动的增加constructor属性
jQuery.prototype={
    constructor:jQuery,
    ...
}

----------


window.jQuery=window.$=jQuery;
}();
```

---
####函数的三种角色
>**` 特别注意: `**
>**（Function的原型是一个匿名空函数（anonymous），它是函数数据类型的，不是对象类型的（但是操作做来和其它类的原型一模一样）有什么用呢，）**

---
#####1，普通函数:  它本身就是一个普通的函数，执行的时候形成私有的作用域(闭包),形参赋值,预解释，代码执行完成后栈内存销毁/不销毁
>私有作用域、形参赋值、变量提升、代码执行、返回值、arguments、栈内存的销毁不销毁、作用域链。。。

#####2，类:它有自己的实例，也有一个叫做prototype属性是自己的原型，它的实例都可以指向自己的原型
>实例、类、instanceof、constructor、prototype、\__proto__、y原型链。。。

#####3，普通对象:和var obj = {}中的obj一样，就是一个普通的对象，它作为对象可以有一些自己的私有的属性，也可以通过__proto__找到Function.prototype
>就把它当做一个普通的obj即可，有自己的属性名和属性值。。。
>=>  name：‘函数名’
>=>  length：形参的个数  (内置类的length值都为：1，例如：Number、Object)
>=>  prototype
>=>  \__proto__
>=>  ...
<font color=red>三种角色之间没有必然的关系</font>

![Alt text](./1501675715438.png)

<font color=red>三种角色之间没有必然的关系</font>

----------------------------

>课后思考题:BAT经典面试题
```
1. function Foo() {
2.   getName = function () {
3.       console.log(1);
4.   };
5.   console.log('this is' + this);
6.   return this;
7.}
8.Foo.getName=function () {
9.   console.log(2);
10.};
11.Foo.prototype.getName=function(){
12.   console.log(3);
13.};
14.var getName = function () {
15.   console.log(4);
16.};
17.function getName() {
18.   console.log(5);
19.}
20.Foo.getName();
21.getName();
22.Foo().getName();
23.getName();
24.new Foo.getName();
25.new Foo().getName();
26.new new Foo().getName();
```
```
function Fn(num) {
    this.x = this.y = num;
}
Fn.prototype = {
    x: 20,
    sum: function () {
        console.log(this.x + this.y);
    }
};
var f = new Fn(10);

console.log(f instanceof Fn);//->TRUE
console.log(f instanceof Object);//->TRUE

console.log(f.sum === Fn.prototype.sum);
f.sum();
Fn.prototype.sum();
console.log(f.constructor);

```



---
####CALL/APPLY/BIND
>属于Function.prototype上定义的三个方法，所有的函数数据类型值都都可以调取这三种方法
>
>三个方法都是用来改变一个函数中This关键字指向的(BIND不兼容IE6~8，其余两个方法兼容所有的浏览器)

#####CALL
**call语法：[函数].call（[context],paral，para2。。。）**
**call的作用：**
- 1，把需要操作函数中的this变为第一个实参的值（[context]），
	- [非严格模式下]
		- 第一个实参为空或者写null或者undefind，this都是window，除了这些情况剩下的第一个实参是谁，this就是谁
	- [严格模式下]
		- 第一个实参为空，this是undefind，其余的写谁this就是谁
		- 改变为this以后把需要操作的函数执行即可， 
- 2，最后在立即把[函数]执行，第二个及以后的参数（para1，para2。。。）都是在给这个[函数]传递实参
**CALL应用：把类数组转换为数组**
>借用数组原型上的slice方法,让slice方法执行的时候,里面的this指向arguments,这样就相当于在操作arguments这个类数组（原因：arguments是类数组,它的结构和数组太相似了,数组的一些循环遍历操作,也同样适用于类数组）
```javascript
1.function fn(){
2.    //arguments:类数组
3.    //var ary=Array.prototype.slice.call(arguments);
4.    var ary=[].slice.call(arguments);
5.}
6.fn(12,23,34);
```
>在JS中，元素集合(HTMLCollection的实例)以及节点集合(NodeList的实例)也都是类数组
>
>这些类数组也可以借用数组原型的方法，实现一些相关的操作，例如：借用slice把类数组转换成数组
```
1.var allTagList = document.getElementsByTagName('*');//->*通配符：获取当前页面中所有的元素标签
2.var ary = Array.prototype.slice.call(allTagList);
3.console.log(ary instanceof Array, ary);//->TRUE,数组
```
>在IE低版本浏览器(IE6~8)中运行，我们发现ARG这个类数组是可以借用数组的方法正常操作的，但是元素集合和节点集合的类数组，无法借用数组原型上的方法，提示：Array.prototype.slice: ‘this’ 不是 JavaScript对象 的错误
>
>所以在IE低版本中，我们把节点或者元素集合转换为数组的时候，就不能偷懒了，需要自己写循环处理
```javascript
1.var oList=document.getElementsByTagName('li');
2.
3.//->IE6~8
4.var ary=[];
5.for(var i=0;i<oList.length;i++){
6.    ary[ary.length]=oList[i];
7.}
```
>综上所述，如果我们想实现一个方法`把列数组转换为数组`，我们需要考虑的事情 
>1、兼容`[].slice.call([类数组])`这种模式的，我们使用这种模式，不能兼容的浏览器，我们使用`循环`一步步的处理 
>2、如何验证是否兼容：不兼容的情况下，浏览器会抛出异常(报错)，换句话说，只要报错了就是不兼容
```javascript
1.function toArray(likeAry) {
2.    var ary = [];
3.    try {
4.        //->如果不报错代表兼容
5.        ary = Array.prototype.slice.call(likeAry);
6.    } catch (e) {
7.        //->报错进入CATCH,代表不兼容(IE6~8)
8.        for (var i = 0, len = likeAry.length; i < len; i++) {
9.            ary[ary.length] = likeAry[i];
10.        }
11.    }
12.    return ary;
13.}
```

---
###APPLY
**apply语法：[函数].apply（[context],[paral，para2。。。]）**
它的语法等同于call，call是一个个的给函数传递参数，
唯一的区别在于apply在给操作的函数传递实参的时候，不是一个个传递的，而是放在一个数组中一起传递的（但是也相当于在一个个传参）

bind：它的语法和call一样，但是作用不一样
bind只是提前把函数中的this改变了，但是并没有立即把函数执行，它属于预先改变THIS（柯理化函数思想）
**APPLY应用：获取数组中的最大值**
**示例如下：**
```
var obj = {
    total: 0
};
function sum(num1, num2) {
    //console.log(this);
    this.total = num1 + num2;
}

// sum(10, 20);//->this:window  =>window.total=30
// obj.sum(10, 20);//->Uncaught TypeError: obj.sum is not a function =>OBJ不具备SUM这个属性,所有不可以通过这种方式把方法中的THIS修改为OBJ

//=> sum.call：sum这个实例通过原型链的查找机制,找到Function.prototype的call方法
//=> sum.call()：把找到的方法执行(执行的是的CALL这个方法)
/*
 * call的作用:
 *  ->把需要操作函数中的this变为第一个实参的值
 *   [非严格模式下]
 *      第一个实参为空或者写null或者undefined,this都是window,剩下的第一个实参是谁,this就是谁
 *
 *   [严格模式下]
 *      第一个实参为空,this是undefined,其余的写谁this就是谁
 *
 *  ->改变为this后，把需要操作的函数执行即可
 */

// sum.call(obj, 10, 20);//->call执行的时候，首先让sum中的this变为obj，然后执行sum，把10和20传给sum
// sum.call();//->this:window  严格:undefined
// sum.call(null);//->this:window 严格:null
// sum.call(undefined);//->this:window 严格:undefined
// sum.call(1);//->this:1

/*
 * apply：它的语法等同于call，唯一的区别在于apply在给操作的函数传递实参的时候，不是一个个传递的，而是放在一个数组中一起传递的(但是也相当于在一个个的传参)
 */

sum.call(obj, 10, 20);
sum.apply(obj, [10, 20]);

/*
 * bind：它的语法和call一样,但是作用不一样
 *  ->bind只是提前把函数中的this改变了，但是并没有立即把函数执行，它属于预先改变THIS（柯理化函数思想）
 */
var obj2 = {name: '张三'};
function fn() {

}
// window.setInterval(fn, 1000);//->每隔1S执行一次FN
// window.setInterval(fn(), 1000);//->创建一个定时器,每隔1S中执行的是FN执行的返回结果=>undefined

// window.setInterval(fn.call(obj2), 1000);//->创建定时器的时候就把FN执行了,虽然改变了THIS,但是1S后执行的是FN的返回结果
// window.setInterval(fn.bind(obj2), 1000);//->创建定时器的时候，提前把FN中的this设置为obj2,1S后执行的是fn
```


---
#####括号表达式
一个括号中有多项，我们能够获取到的永远是**最后一项的<font color=red>“值”**
(12,23)  ->23
（12，obj.fn）->obj.fn的值：也就是fn2；
```javascript
function fn2（）{console.log(this);}
var obj={fn:fn2，name："obj"};
(obj.fn)();//->this:obj
(12,fn,13,obj.fn)();//->this:window  括号表达式中，如果有多项，我们获取到的最后一项如果执行的话，方法中的this是window
```
```javascript
var ary=[12,23,24,25,35,14,16]
//借用Math.max方法，利用apply传递参数是一个数组的原理，实现获取数组中的最大值
var max = Math.max.apply(null, ary);//->apply:虽然写的时候传递的是一个数组,但是也相当于在给max方法一个个传递参数;此处不需要操作this,所以this改为谁都无所谓;

var min = Math.min.apply(null, ary);

console.log(max, min);
```

---
####THIS
>JS中的THIS的几种情况 
和函数在哪定义以及在哪执行都没有任何的关系 
你以为你以为的就是你以为的
```javascript
1.//->1、自执行函数中的this是window
2.~function(){
3.    //this:window
4.}();
5.
6.//->2、给元素的某个事件绑定方法，事件触发，方法执行，方法中的this是当前元素本身
7.function fn(){}
8.document.body.onclick=fn; //->点击BODY，触发FN执行，FN方法中的this:document.body
9.
10.//->3、构造函数执行，函数体中出现的this都是当前类的一个实例
11.function Fn(){
12.    //->this:f
13.    this.x=100;
14.    this.y=200;
15.}
16.Fn.prototype.sum=function(){
17.    return this.x+this.y;
18.}
19.var f=new Fn;
20.
21.//->4、方法执行，看方法前看是否有“.”，有的话，“.”前面是谁this就是谁，没有“.”，this就是window
22.f.sum();//->this:f
23.Fn.prorotype.sum();//->this:Fn.prorotype
24.f.__proto__.sum();//->this:f.__proto__
25.
26.//->5、可以使用call/apply/bind强制改变某一个方法中的this(这个规律的优先级最高)
27.var obj={};
28.function fn(num){}
29.document.body.onclick=fn.bind(obj,100); //->点击的时候执行fn，fn中的this:obj
```
>但是以上都是在非严格的JS模式下，JS还有严格模式，严格模式下和非严格模式有点区别
```
1.'use strict'; //->开启JS的严格模式(严格模式：JS代码更加严谨)
2.
3.//->1、自执行函数中的this是undefined
4.
5.//->2、函数执行，如果没有“.”，this是undefined而不是window
6.
7.//->3、使用call/apply/bind的时候，如果第一个参数不传递，this不是window而是undefined，如果传递的是null/undefined，this指向的就是null/undefined，而不是之前所谓的window了
8.
9.==>严格模式下，如果没有确定执行的主体，this都是undefined，而不是非严格模式下的window了

```


类的初始原型上有prototype这个属性，会默认有constructor